# BP미디어 공개 홈페이지 작업 상태

공개 Site 정본은 이 worktree의 `main`, 배포 정적 루트는 `public/`이다. 연결된 `gilwell-media` worktree는 Mac Writer 작업용이다. 기술 구성과 실행 환경은 `README.md`, 승인·타겟별 규칙은 `AGENTS.md`와 `rules/`를 따른다.

## 2026-10-04 — 홈 스카우트 활동 안내 디자인

- `public/index.html`: 공통 `home-section-title`과 `home-rail-card`로 제목과 본문을 구성했다. 설명·네 주제 링크는 유지했다.
- `public/css/m3-site.css`, `public/css/topics.css`: 기존 M3 칩 규칙을 재사용하고 설명 크기·여백을 정리했다. 주제 상세 페이지 링크 스타일은 보존했다.
- 검증: 설치된 Chrome으로 1440/390/360/320px에서 가로 넘침 없음, 네 링크 44px 높이와 밑줄 제거 확인, 키보드 포커스 3px 확인. 데스크톱·모바일 캡처 시각 확인. APCA 본문 97.6, 칩 85.3, 포커스 84.4. `git diff --check` 통과. 원격 P0 조회 0건.
- 범위/위험: 공개 정적 HTML·CSS만 변경. 운영 데이터·인증·API 변경 없음. 로컬 검증이며 운영 반영은 승인 대기다.
- 검증 환경 참고: 기본 Playwright Chromium 실행 파일이 없어 최초 실행 실패. 추가 설치 없이 `channel: 'chrome'`으로 실제 브라우저 검증 완료. 정적 서버에는 API가 없어 홈 데이터 오류 알림이 표시되며 운영 오류의 증거가 아니다.
- 다음 작업: 사용자 커밋·배포 승인 후 `rules/02-versioning.md`, `rules/03-deploy.md`를 읽고 버전·changelog·자산 버전 동기화 및 release preflight를 수행한 다음 표준 배포와 라이브 화면 검증을 진행한다.

## 2026-10-08 — 단계별 아이콘 버튼과 사이트맵 검수

- 사용자 승인: 이번 요청의 내부 검수 2회 이후 커밋·푸시·production 배포 자동 진행.
- 기존 미배포 홈 스타일 변경을 보존·활용하며 네 링크에 발자국/나침반/산/악수 SVG를 추가했다. 공개 링크 의미와 목적지를 유지했다.
- 사이트맵: 배포 전 apex·www 리다이렉트·Googlebot·Yeti GET에서 일반/뉴스 XML 정상. 보고된 HTML 응답은 재현되지 않았으며 정확한 오류 URL 확인 대기. 원인 해결을 단정하지 않는다.
- 응답 길이만 검사하던 기존 회귀 검사를 XML Content-Type·GET/HEAD·HTML 부재 확인으로 강화하고 표준 배포 후 검사에 두 XML 파싱을 추가했다.
- SQLite fixture의 special_feature 누락으로 사이트맵 오류가 숨겨지던 기존 테스트를 수정하고 공개 기사 포함/초안 제외를 확인했다.
- 검증/실패 근거: work/gpt-scout-buttons-20261008. 운영 데이터·인증 변경 없음. 잔여위험은 검색서비스가 기록한 과거 오류/실제 색인 상태 미확인.

- 내부 검수 1회: SQLite/주제 페이지 및 라이브 XML GET/HEAD 통과, Chrome 1440/390/360/320 캡처 확인. 320px 줄 배치 개선 필요 발견.
- 내부 검수 2회: 모바일 2열 정리 후 UI 회귀/주제 SQLite/XML 검사 모두 통과, 4폭 캡처 확인. APCA 라벨85.34·포커스84.41, 메타데이터·노출 경계·diff 검사 통과.
- 기존 2026-10-03 외장 암호화 D1/R2 백업 파일 readback SHA256을 검증 기록과 대조해 일치 확인. 이 요청은 데이터 모델/DB 변경 없음, 이전 커밋 및 이번 release snapshot으로 코드 롤백 가능.

## 2026-10-08 — 후속 균등 너비/가운데 정렬

- 기존 카드/아이콘/링크를 보존하고 홈 안내 링크를 4열 균등 Grid, 768px 이하 2열로 적용. 설명문 가운데 정렬.
- 6폭(1440/800/768/601/390/320) 회귀 검사에서 동등 너비, 우측 카드 끝 정렬, 행 수, 설명문 중앙, 높이/포커스/넘침 확인. 1차 검사 통과; 2차 캡처·메타데이터 검사 후 기존 승인으로 커밋/배포.
- P0 D1 최초7403는 과거 사례를 확인하고 read-only1회 재시도 성공(0건). 운영 쓰기0.

## 2026-10-08 — 용어집 현행화

- 회원국 현황 revision5의230개 조직 대조. 기존36개 조직 정비, 미등재194개 조직+기본 용어8개 추가. 총133→335개; 기존93개 항목 수정. ID·생성일·불어 및 기존 별칭 설명 보존.
- 미국은 공식 자료로 확인한 Scouting America 유지. 한국어 공식명이 미확정인54개 조직은 원문 유지, 신규 국가별 국문명은 안내 명칭임을 명시. NSO/연합/NSA/연계 단체 구분.
- 영문 오탈자·용어 의미 정비, 빈 설명 보완. 현행화 날짜 및 회원국 현황 링크 표시.
- 기존 bucket CHECK 가나다14개 제한 확인. storageBucket을 POST·PUT에 공용 적용, 공개 분류 보존. 인증·권한·스키마 변경 없음. KMS9.2.1/14 기록 후 D1 원본 스냅샷 동기화.
- 검수1: 명칭·분류·한도·중복·230개 조직 연결,133행 암호화 백업 인증·SQLite 복원. 검수2: 실제 CHECK 기반 SQL 재실행·동시 수정 보호·기존 번역/ID 보존 및 공용 저장 매핑 검사.
- 원격 반영: import RESET_DO2회 실패 후133행 보존 확인. bounded query 전환 중 CHECK 및 임시 실행기의 다중행 분리 오류 수정. 최종335개 모든 변경 필드·추가 항목 독립 원격 export/API 대조 완료. 공유 failures/gpt-2026-10-08-bpmedia-glossary-d1-reset.md에 기록.
- 백업: 외장 Project_Server_Backups/bpmedia/20261008-glossary-before.json.enc 및 KMS 암호화 전본; 키는 기기 로컬. 근거 work/gpt-glossary-20261008.
- 잔여위험: 사이트 회원국 현황 기준이며230개 단체의 공식 한국어 번역을 확정한 작업은 아니다. 관리자 실제 계정 저장은 수행하지 않았으며 저장 매핑 회귀/인증경계/실데이터 조회로 확인. 사용자 승인으로 커밋·푸시·표준production 배포.
- 최종 검수: live API335건·54국문 미확정, 실제 변경 필드 전체 일치. SQL/저장 매핑/메타데이터/공개 노출/diff 검증 통과.


## 2026-10-20 — Owner phone replacement (deployed)

public/about.html updates Jimmy Park's management contact to +82.10.2646.1635, tel:+821026461635 and JSON-LD +82-10-2646-1635. Other contacts and layout are unchanged. main matches origin/main; P0 query returned zero open/monitoring high/critical issues (first transient7403, retry succeeded). Mac Writer sibling about.html is synchronized to prevent reintroducing the retired number. Released with owner approval through rules/02-versioning.md and rules/03-deploy.md.

Owner approved commit/push/deploy. Public commit202191a5 pushed to main; standard production script deployed7d4d4881.gilwell-media.pages.dev, site00.194.01. Live About telephone and ContactPoint JSON-LD match the new number, retired number absent. Post-deploy version and sitemap checks passed. Writer sibling commitf9662d60 pushed to feat/bpmedia-mac-writer-v1. No phone-call test was performed; screenshot capture was unavailable, browser accessibility and independent HTTP were verified. Final public post audit:511 published posts,0 issues. Release snapshot20261019T165953Z-202191a5 saved successfully.

## 2026-10-23 — 주간 카드뉴스 자동 제작 (Admin)

- 승인된 세계스카우트 에셋/Wanted Sans/이사만루 1080×1350 디자인을 기존 카드뉴스 메뉴에 연결. 새 호만 주간 스튜디오, 기존 호는 기존 편집기 유지.
- 매주 월요일 09:00 KST의 직전 한 주, 이미지·본문을 확인한 기사로 편집 가능한 호 생성. 자동 게시 없음. 기사 선택·사진 위치 서버 저장, PNG/ZIP은 필요할 때 생성.
- D1 기존 테이블 사용, 인증·권한 재사용, revision 충돌 방지와 동일 기간 덮어쓰기 방지. 원문 posts 변경 없음.
- 구현/로컬 검증 완료. 기존 미커밋 Site 변경 보존. 사용자가 이번 변경만 커밋·푸시·운영 배포·cron 활성화를 명시 승인. 별도 깨끗한 배포용 복사본에서 이번 변경만 반영한다. 운영 로그인 확인은 배포 후 수행.
- 상세: docs/features/Weekly Card News.md. Admin 03.159.00 준비.

## 2026-10-23 — 주간 카드뉴스 디자인 스튜디오

- Admin03.160.00: 표지8종 무작위 선택(새 호에 한번 저장), 기사 배치4종, 문구·타이포·사진 높이/맞춤 조절. 기존 호의 디자인/사진과 posts를 보존한다.
- 기존 인증 프레임·PNG/ZIP·CAS를 재사용. latest renderId를 확인하여 빠른 입력 후에도 마지막 디자인을 내보낸다. 데이터/권한/서버 입력 경계 검사 통과, 실제 Chrome 8표지·4기사 레이아웃·최대값·긴 문구·저장재접속·사진·PNG/ZIP·모바일 검사 통과.
- 자동제작 cron은 기존 월요일00:00 KST를 유지. 10월26일 첫 실행을00:05에 읽기 전용으로 확인하는 일회성 Codex heartbeat(bp)를 별도로 등록했다. 첫 실행 자체는 아직 미래다.
- 기존 dirty checkout은 보존하며 깨끗한 weekly-release 복사본에서 카드뉴스 범위만 커밋·배포한다. 공유 패키지 변경을 포함하므로 scheduled Worker도 같은 helper로 재배포한다.


## 2026-10-27 — KMS 운영 기준 최신화

- 타겟 KMS. 운영 커밋4699dab1에서 분리한 작업 사본으로 진행하고 원래 공유 checkout의 미완료 Site 변경을 보존했다.
- 2026-10-24 카드뉴스 수동 전용 결정, 표지/기사 편집·권한·저장 충돌·PNG 검수, 용어집 검색 범위 복구, 설정 쓰기 권한을 KMS에 반영했다. 기존 자동 추천 승인 기준과 구형 수동 안내의 충돌 및 규칙/배포 경로도 정리했다.
- D1 revision4→6. 변경 전 본문은 settings_history에 보관하고 조건부 갱신·운영 로그·전체 readback을 확인했다. 원본에서 Markdown/fallback을 공식 스크립트로 동기화했다.
- KMS API 가이드의 로그인·세션·revision 예시를 정정하고 카드뉴스 API8개를 추가했다. 기능 동작·인증 코어·기사/카드 데이터·예약은 변경하지 않았다.
- 검증: SQL fixture 정상·stale·재실행, 설정 쓰기 권한4건, 카드뉴스 예약 비활성 검사, JS 문법·스냅샷 일치. 1440/390px 로컬 KMS 렌더·API8개·표시일·가로 넘침 없음·pageerror0 확인. Admin03.160.04 릴리스 준비. 배포 결과는 종료 시 추가한다.
- 후속 확인: KMS5.2의 과거 티커 버튼 제거 기록과5.9의 직접 정지 접근성 기준은 현재 조작 방식 검토가 필요하다. 이번 작업에서 Site 기능이나 기준을 임의 변경하지 않았다.
- 다음 시작: AGENTS.md→rules/README.md→rules/30-kms.md, PROJECT_CONTEXT.md를 읽고 git status --short, node scripts/sync_kms_snapshot.mjs --check, ./scripts/verify_release_metadata.sh 실행.
