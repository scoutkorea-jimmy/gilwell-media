(function () {
  'use strict';

  if (typeof window === 'undefined' || typeof document === 'undefined' || !window.GW || !window.GW.HomeHelpers) return;

  var GW = window.GW;
  var helpers = GW.HomeHelpers;
  var HOME_COLUMN_KEYS = ['korea', 'apr', 'wosm', 'people'];
  var HOME_MINI_SECTIONS = [
    { id: 'latest-list', source: 'latestRail', empty: '아직 게시글이 없습니다' },
    { id: 'popular-list', source: 'popularRail', empty: '아직 게시글이 없습니다' },
    { id: 'popular-list-mobile', source: 'popularRail', empty: '아직 게시글이 없습니다' },
    { id: 'picks-list', source: 'picksRail', empty: '에디터 추천 게시글이 없습니다' },
    { id: 'picks-list-mobile', source: 'picksRail', empty: '에디터 추천 게시글이 없습니다' }
  ];

  function buildMiniItem(post, options) {
    var miniFrameStyle = post.image_is_placeholder ? '' : GW.thumbFrameStyle(post);
    var thumb = post.image_url
      ? '<img class="mini-thumb' + (post.image_is_placeholder ? ' is-placeholder' : '') + '" src="' + GW.escapeHtml(post.image_url) + '"' + (miniFrameStyle ? ' style="' + miniFrameStyle + '"' : '') + ' loading="lazy" alt="' + GW.escapeHtml(post.title || '') + '">'
      : '';
    // 카드 전체 영역 클릭 → 기사 이동. tabindex=-1 + aria-hidden으로 키보드/SR에는 기존 title anchor만 노출(중복 링크 회피).
    var overlayHref = '/post/' + post.id;
    return (
      '<article class="mini-item has-overlay-link">' +
        '<a class="mini-item-overlay" href="' + overlayHref + '" tabindex="-1" aria-hidden="true"></a>' +
        '<div class="mini-item-row">' +
          '<div class="mini-item-text">' +
            '<div class="mini-item-labels">' + helpers.buildMiniLabels(post, options) + '</div>' +
            '<h4><a class="mini-item-link" href="' + overlayHref + '">' + GW.escapeHtml(post.title) + '</a></h4>' +
            '<div class="mini-meta">' + GW.renderPostDateLabel(post) + '</div>' +
          '</div>' +
          thumb +
        '</div>' +
      '</article>'
    );
  }

  function renderLeadStory(el, post, label, leadMedia, options) {
    if (!el) return;
    var opts = options || {};
    if (opts.error) {
      helpers.renderHomeBlockError(el, 'lead');
      return;
    }
    if (!post) {
      el.innerHTML = '<div class="mini-empty">대표 기사를 준비 중입니다</div>';
      return;
    }
    var cat = GW.CATEGORIES[post.category] || GW.CATEGORIES.korea;
    var categoryLabel = GW.getCategoryLabel(post.category);
    var subtitle = (post.subtitle || '').trim();
    // /api/home 은 이제 content 대신 서버가 만든 excerpt 를 보낸다. content 폴백은
    // 이 배포 이전에 localStorage 에 저장된 캐시 페이로드를 위해 남겨 둔다.
    var excerpt = post.excerpt || GW.truncate(post.content || '', 420);
    var tags = helpers.getSortedPostTags(post);
    if (excerpt === subtitle) excerpt = '';

    var thumb = post.image_url
      ? '<a class="home-lead-thumb-link' + (helpers.isTransparentPng(post.image_url) ? ' is-png' : '') + (post.image_is_placeholder ? ' is-placeholder' : '') + '" style="' + helpers.getResponsiveMediaStyle(leadMedia) + '" href="/post/' + post.id + '">' +
          '<span class="home-lead-thumb-backdrop" aria-hidden="true" style="background-image:url(' + GW.escapeHtml(post.image_url) + ')"></span>' +
          '<img class="home-lead-thumb' + (post.image_is_placeholder ? ' is-placeholder' : '') + '" src="' + GW.escapeHtml(post.image_url) + '" alt="' + GW.escapeHtml(post.title) + '" loading="eager" fetchpriority="high" decoding="async">' +
        '</a>'
      : '';

    el.innerHTML =
      '<article class="home-lead-card">' +
        thumb +
        '<div class="home-lead-body">' +
          '<div class="home-lead-copy">' +
            '<div class="home-lead-labels">' +
              '<span class="category-tag ' + cat.tagClass + '">' + GW.escapeHtml(categoryLabel) + '</span>' +
              tags.map(function (tag) {
                return GW.postTagChip(tag, post.category);
              }).join('') +
              '<span class="home-lead-kicker">' + GW.escapeHtml(label || '메인 스토리') + '</span>' +
              (GW.isPostNew(post) ? '<span class="post-kicker post-kicker-new">NEW</span>' : '') +
            '</div>' +
            '<h3><a class="home-lead-link" href="/post/' + post.id + '">' + GW.escapeHtml(post.title) + '</a></h3>' +
            (subtitle ? '<p class="home-lead-subtitle">' + GW.escapeHtml(subtitle) + '</p>' : '') +
            (excerpt ? '<p class="home-lead-excerpt">' + GW.escapeHtml(excerpt) + '</p>' : '') +
          '</div>' +
          '<div class="home-lead-footer">' +
            '<div class="home-lead-meta">' + GW.renderPostDateLabel(post) + (post.author ? ' · ' + GW.escapeHtml(post.author) : '') + '</div>' +
            '<div class="home-lead-actions">' +
              '<a class="home-subscribe-btn" href="/post/' + post.id + '">기사 읽기</a>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</article>';
  }

  function renderMiniList(el, posts, emptyMsg, options) {
    if (!el) return;
    var opts = options || {};
    if (opts.errorKey) {
      helpers.renderHomeBlockError(el, opts.errorKey);
      return;
    }
    if (!posts || !posts.length) {
      el.innerHTML = '<div class="mini-empty">' + (emptyMsg || '게시글이 없습니다') + '</div>';
      return;
    }
    el.innerHTML = posts.map(function (post) {
      return buildMiniItem(post, options);
    }).join('');
  }

  function buildHomeSections(data) {
    var issues = helpers.getHomeIssueMap(data);
    var latestPosts = helpers.sortPostsLatest(data.latest && data.latest.posts ? data.latest.posts : []);
    var popularPosts = data.popular && data.popular.posts ? data.popular.posts : [];
    var picksPosts = data.picks && data.picks.posts ? data.picks.posts : [];
    return {
      latestPosts: latestPosts,
      popularPosts: popularPosts,
      picksPosts: picksPosts,
      columns: data.columns || {},
      latestRail: latestPosts.slice(0, 3),
      popularRail: issues.popular ? [] : (popularPosts.length ? popularPosts : latestPosts).slice(0, 4),
      picksRail: picksPosts.slice(0, 4)
    };
  }

  function miniSectionErrorKey(sectionSource, issues) {
    var key = sectionSource === 'latestRail'
      ? 'latest'
      : sectionSource === 'popularRail'
        ? 'popular'
        : sectionSource === 'picksRail'
          ? 'picks'
          : '';
    return issues[key] ? key : '';
  }

  function applyMiniSections(viewModel, issues) {
    HOME_MINI_SECTIONS.forEach(function (section) {
      renderMiniList(
        document.getElementById(section.id),
        viewModel[section.source] || [],
        section.empty,
        { errorKey: miniSectionErrorKey(section.source, issues) }
      );
    });

    HOME_COLUMN_KEYS.forEach(function (key) {
      renderMiniList(
        document.getElementById('col-' + key),
        viewModel.columns[key] && viewModel.columns[key].posts ? viewModel.columns[key].posts.slice(0, 4) : [],
        '게시글이 없습니다',
        {
          // 4-컬럼이 카테고리별 그룹이지만, 사이트 전반에서 카테고리 칩이
          // 일관되게 보이도록 hideCategoryChip 해제 (2026-05-27 일관성 회복).
          errorKey: issues[key] ? key : ''
        }
      );
    });

    // 모든 레일을 그린 뒤 한 번에 클램프한다. 항목별로 하면 레이아웃을 여러 번
    // 강제로 계산하게 된다.
    GW.fitPostTagRows();
  }

  GW.HomeRender = {
    renderLeadStory: renderLeadStory,
    renderMiniList: renderMiniList,
    buildHomeSections: buildHomeSections,
    applyMiniSections: applyMiniSections,
    HOME_COLUMN_KEYS: HOME_COLUMN_KEYS,
    HOME_MINI_SECTIONS: HOME_MINI_SECTIONS
  };
})();
