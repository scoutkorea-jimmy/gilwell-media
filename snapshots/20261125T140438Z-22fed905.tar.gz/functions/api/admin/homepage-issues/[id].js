import { queryRust } from '../../../_shared/rust-server.js';
import { extractToken, verifyTokenRole } from '../../../_shared/auth.js';
import { gateMenuAccess } from '../../../_shared/admin-permissions.js';
import { requireOtp } from '../../../_shared/otp-session.js';
import { ensureHomepageIssuesTable, normalizeHomepageIssue, HOMEPAGE_ISSUE_STATUS_OPTIONS } from '../../../_shared/homepage-issues.js';
import { deriveIp, logOperationalEvent } from '../../../_shared/ops-log.js';

export async function onRequestPatch({ request, env, params }) {
  const __gate = await gateMenuAccess(request, env, 'homepage-issues', 'write'); if (__gate) return __gate
  const __otp = await requireOtp(request, env); if (__otp) return __otp;
  const id = parseId(params && params.id);
  if (!id) return json({ error: '유효하지 않은 이슈 ID입니다.' }, 400);
  await ensureHomepageIssuesTable(env);

  let body;
  try {
    body = await request.json();
  } catch (_) {
    return json({ error: 'Invalid JSON' }, 400);
  }
  const nextStatus = normalizeStatus(body && body.status);
  if (!nextStatus) return json({ error: '유효하지 않은 상태값입니다.' }, 400);

  const lookup = await queryRust({ env, request }, 'homepage-issue-get', { id });
  if (!lookup.ok) throw new Error('Rust homepage issue lookup failed');
  const { row: current } = await lookup.json();
  if (!current) return json({ error: '이슈를 찾지 못했습니다.' }, 404);
  const prev = normalizeHomepageIssue(current);
  if (prev.status === nextStatus) {
    return json({ ok: true, item: prev, unchanged: true }, 200);
  }

  const resolvedAt = nextStatus === 'resolved'
    ? (prev.resolved_at || nowUtcText())
    : null;
  const result = await queryRust({ env, request }, 'homepage-issue-status', { id, status: nextStatus, resolvedAt });
  if (!result.ok) throw new Error('Rust homepage issue status update failed');
  const { row: updated } = await result.json();
  const item = normalizeHomepageIssue(updated);
  await logOperationalEvent(env, {
    channel: 'admin',
    type: 'homepage_issue_status_changed',
    level: 'info',
    path: '/api/admin/homepage-issues/' + id,
    ip: deriveIp(request),
    message: 'Homepage issue status changed',
    details: {
      id,
      title: item.title,
      from_status: prev.status,
      to_status: item.status,
    },
  });
  return json({ ok: true, item }, 200);
}

export async function onRequestDelete({ request, env, params }) {
  const __gate = await gateMenuAccess(request, env, 'homepage-issues', 'write'); if (__gate) return __gate
  const __otp = await requireOtp(request, env); if (__otp) return __otp;

  const id = parseId(params && params.id);
  if (!id) return json({ error: '유효하지 않은 이슈 ID입니다.' }, 400);

  await ensureHomepageIssuesTable(env);
  await logOperationalEvent(env, {
    channel: 'admin',
    type: 'homepage_issue_manual_blocked',
    level: 'warning',
    path: '/api/admin/homepage-issues/' + id,
    ip: deriveIp(request),
    message: 'Manual homepage issue delete blocked',
    details: { method: 'DELETE', id },
  });
  return json({ error: '홈 오류/이슈 기록은 자동 감지로만 누적됩니다.' }, 403);
}

function parseId(raw) {
  const parsed = parseInt(raw, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 0;
}

function normalizeStatus(raw) {
  const value = String(raw || '').trim().toLowerCase();
  return HOMEPAGE_ISSUE_STATUS_OPTIONS.includes(value) ? value : '';
}

function nowUtcText() {
  return new Date().toISOString().slice(0, 19).replace('T', ' ');
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-store',
    },
  });
}
