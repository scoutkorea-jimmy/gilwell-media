import { singleSetting, compareAndSetSetting, queryRust } from '../../_shared/rust-server.js';
/**
 * Gilwell Media · Editors Setting
 *
 * GET /api/settings/editors  ← admin (view), returns editor letter→name map (A-Z)
 * PUT /api/settings/editors  ← admin (write), update editor names
 *
 * Stored in settings table as key='editors', value=JSON { "A": "name", "B": "", ... }
 * Letters A/B/C are always present (historical posts reference Editor.A/B/C) and
 * cannot be dropped. Letters D-Z are optional and may be freely added/removed
 * by the operator. Internal names are NOT shown publicly on posts — only used
 * in the admin panel for routing real-name overrides.
 */
import { verifyTokenRole, extractToken } from '../../_shared/auth.js';
import { gateMenuAccess } from '../../_shared/admin-permissions.js';
import { recordSettingChange } from '../../_shared/settings-audit.js';

const REQUIRED_LETTERS = ['A', 'B', 'C'];
const LETTER_RE = /^[A-Z]$/;
const MAX_NAME_LEN = 60;

function normalizeEditors(stored) {
  const out = {};
  REQUIRED_LETTERS.forEach((l) => { out[l] = ''; });
  if (stored && typeof stored === 'object') {
    Object.keys(stored).forEach((rawKey) => {
      const key = String(rawKey || '').trim().toUpperCase();
      if (!LETTER_RE.test(key)) return;
      const value = stored[rawKey];
      out[key] = (typeof value === 'string') ? value.trim().slice(0, MAX_NAME_LEN) : '';
    });
  }
  return out;
}

export async function normalizeEditorsRust(stored, env = {}, run = queryRust) {
  const fallback = () => normalizeEditors(stored);
  try {
    const entries = stored && typeof stored === 'object' ? Object.entries(stored) : [];
    if (/\\u[dD][89a-fA-F][0-9a-fA-F]{2}/.test(JSON.stringify(entries))) return fallback();
    const response = await run({env,request:{url:'https://internal.invalid/'}}, 'editors-normalize', {entries});
    if (!response.ok) return fallback();
    const result = await response.json();
    if (!Array.isArray(result.entries)) return fallback();
    const normalized = {A:'',B:'',C:''};
    for (const entry of result.entries) {
      if (!Array.isArray(entry) || typeof entry[0] !== 'string' || !LETTER_RE.test(entry[0]) || !Array.isArray(entry[1]) || entry[1].length > MAX_NAME_LEN || !entry[1].every(n=>Number.isInteger(n) && n>=0 && n<=65535)) return fallback();
      normalized[entry[0]] = String.fromCharCode(...entry[1]);
    }
    return normalized;
  } catch { return fallback(); }
}

export async function onRequestGet({ request, env }) {
  // Require auth — editor real names are private
  const __gate = await gateMenuAccess(request, env, 'editors', 'view'); if (__gate) return __gate

  try {
    const row = await singleSetting(env, 'editors');
    const stored = row ? JSON.parse(row.value) : {};
    return json({ editors: await normalizeEditorsRust(stored, env) });
  } catch (err) {
    if (request && new URL(request.url).searchParams.get('scope') === 'admin') return json({ error: '설정을 불러오지 못했습니다. 다시 시도해주세요.' }, 500);
    console.error('GET /api/settings/editors error:', err);
    return json({ editors: normalizeEditors(null) });
  }
}

export async function onRequestPut({ request, env }) {
  const __gate = await gateMenuAccess(request, env, 'editors', 'write'); if (__gate) return __gate

  let body;
  try { body = await request.json(); } catch {
    return json({ error: 'Invalid JSON' }, 400);
  }

  const { editors } = body;
  if (!editors || typeof editors !== 'object') {
    return json({ error: 'editors 객체를 입력해주세요' }, 400);
  }

  const safe = await normalizeEditorsRust(editors, env);

  try {
    const prevRow = await singleSetting(env, 'editors');
    if (body.if_current && JSON.stringify(await normalizeEditorsRust(body.if_current.editors, env)) !== JSON.stringify(await normalizeEditorsRust(prevRow ? JSON.parse(prevRow.value) : {}, env))) return json({ error: '저자명이 다른 화면에서 변경되었습니다. 입력을 보존하고 최신 값을 확인해주세요.' }, 409);
    const changes = await compareAndSetSetting(env, 'editors', JSON.stringify(safe), prevRow ? prevRow.value : null);
    if (changes !== 1) return json({ error: '동시 저자명 변경이 감지되었습니다.' }, 409);
    await recordSettingChange(env, {
      key: 'editors',
      previousValue: prevRow && prevRow.value,
      path: '/api/settings/editors',
      message: '에디터 실명 설정 변경',
      details: { letterCount: Object.keys(safe).length },
    });
    return json({ editors: safe });
  } catch (err) {
    console.error('PUT /api/settings/editors error:', err);
    return json({ error: 'Database error' }, 500);
  }
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-store',
    },
  });
}
