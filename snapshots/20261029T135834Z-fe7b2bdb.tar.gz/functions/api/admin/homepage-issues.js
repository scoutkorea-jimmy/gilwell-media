import { queryRust } from '../../_shared/rust-server.js';
import { extractToken, verifyTokenRole } from '../../_shared/auth.js';
import { gateMenuAccess } from '../../_shared/admin-permissions.js';
import { requireOtp } from '../../_shared/otp-session.js';
import { ensureHomepageIssuesTable, normalizeHomepageIssue } from '../../_shared/homepage-issues.js';
import { deriveIp, logOperationalEvent } from '../../_shared/ops-log.js';

export async function onRequestGet({ request, env }) {
  const __gate = await gateMenuAccess(request, env, 'homepage-issues', 'view'); if (__gate) return __gate
  const __otp = await requireOtp(request, env); if (__otp) return __otp;

  try {
    await ensureHomepageIssuesTable(env);
    const url = new URL(request.url);
    const q = String(url.searchParams.get('q') || '').trim();
    const status = String(url.searchParams.get('status') || 'all').trim().toLowerCase();
    const limit = Math.max(1, Math.min(200, parseInt(url.searchParams.get('limit') || '100', 10) || 100));
    const rust = await queryRust({ env, request }, 'homepage-issue-list', { q, status, limit });
    if (!rust.ok) throw new Error('Rust homepage issue list failed');
    const { items: results } = await rust.json();
    return json({ items: (results || []).map(normalizeHomepageIssue) });
  } catch (err) {
    console.error('GET /api/admin/homepage-issues error:', err);
    return json({ error: 'Database error' }, 500);
  }
}

export async function onRequestPost({ request, env }) {
  const __gate = await gateMenuAccess(request, env, 'homepage-issues', 'write'); if (__gate) return __gate
  const __otp = await requireOtp(request, env); if (__otp) return __otp;
  await logOperationalEvent(env, {
    channel: 'admin',
    type: 'homepage_issue_manual_blocked',
    level: 'warning',
    path: '/api/admin/homepage-issues',
    ip: deriveIp(request),
    message: 'Manual homepage issue creation blocked',
    details: { method: 'POST' },
  });
  return json({ error: '사이트 오류/이슈 기록은 자동 감지로만 누적됩니다.' }, 403);
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-store',
    },
  });
}
