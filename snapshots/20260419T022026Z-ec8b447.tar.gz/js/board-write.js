(function () {
  'use strict';

  if (typeof window === 'undefined' || !window.GW || !window.GW.Board) return;

  var GW = window.GW;
  var Board = GW.Board;

  function syncBoardTagPills(sel, selectedTags) {
    sel.querySelectorAll('.tag-pill').forEach(function (b) {
      var t = b.dataset.tag || '';
      if (t === '') {
        b.classList.toggle('active', selectedTags.length === 0);
      } else {
        b.classList.toggle('active', selectedTags.indexOf(t) >= 0);
      }
    });
  }

  Board.prototype._setupWriteFeature = function () {
    var self = this;
    var cat = GW.CATEGORIES[this.category] || GW.CATEGORIES.korea;

    var textEl = document.querySelector('.board-banner-text');
    if (textEl) {
      var btn = document.createElement('button');
      btn.className = 'write-btn';
      btn.textContent = '✏ 글쓰기';
      btn.addEventListener('click', function () { self._showPasswordModal(); });
      textEl.appendChild(btn);
    }

    var pwOverlay = document.createElement('div');
    pwOverlay.id = 'board-pw-overlay';
    pwOverlay.className = 'board-pw-overlay';
    pwOverlay.innerHTML =
      '<div class="board-pw-box">' +
        '<div class="board-pw-header">글쓰기</div>' +
        '<p class="board-pw-desc">관리자 비밀번호를 입력하세요</p>' +
        '<input type="password" id="board-pw-input" placeholder="비밀번호" autocomplete="current-password" />' +
        '<div id="board-pw-turnstile" style="margin:12px 0;"></div>' +
        '<div id="board-pw-error" class="board-pw-error">관리자만 글을 쓸 수 있습니다</div>' +
        '<div class="board-pw-actions">' +
          '<button id="board-pw-submit">확인</button>' +
          '<button id="board-pw-cancel">취소</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(pwOverlay);

    document.getElementById('board-pw-submit').addEventListener('click', function () { self._checkPassword(); });
    document.getElementById('board-pw-cancel').addEventListener('click', function () { self._closePasswordModal(); });
    document.getElementById('board-pw-input').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') self._checkPassword();
      if (e.key === 'Escape') self._closePasswordModal();
    });
    pwOverlay.addEventListener('click', function (e) {
      if (e.target === pwOverlay) self._closePasswordModal();
    });

    var writeOverlay = document.createElement('div');
    writeOverlay.id = 'board-write-overlay';
    writeOverlay.className = 'board-write-overlay';
    writeOverlay.innerHTML =
      '<div class="board-write-box" role="dialog" aria-modal="true" aria-labelledby="board-write-heading">' +
        '<button class="board-write-close" id="board-write-close" aria-label="닫기">×</button>' +
        '<div class="board-write-header" id="board-write-heading">새 게시글 작성</div>' +
        '<span class="board-write-cat" style="background:' + cat.color + '">' + cat.label + '</span>' +
        '<div class="form-group" style="margin-top:20px;">' +
          '<label for="board-write-title-input">제목 *</label>' +
          '<input type="text" id="board-write-title-input" placeholder="게시글 제목을 입력하세요" maxlength="200" />' +
        '</div>' +
        '<div class="form-group">' +
          '<label for="board-write-subtitle-input">부제목</label>' +
          '<input type="text" id="board-write-subtitle-input" placeholder="부제목을 입력하세요 (선택)" maxlength="300" />' +
        '</div>' +
        '<div class="form-group">' +
          '<label for="board-write-special-feature">특집 기사 묶음명 <span style="font-size:10px;color:var(--muted);font-family:NixgonFont,sans-serif;">클릭하여 기존 목록 선택 또는 새 이름 직접 입력</span></label>' +
          '<div class="sf-autocomplete-wrap" style="position:relative;">' +
            '<input type="text" id="board-write-special-feature" placeholder="예: 세계잼버리 리더십 특집 (선택)" maxlength="120" autocomplete="off" />' +
            '<div id="board-sf-dropdown" class="sf-dropdown" style="display:none;position:absolute;top:100%;left:0;right:0;z-index:200;background:var(--bg);border:1px solid var(--border);max-height:180px;overflow-y:auto;"></div>' +
          '</div>' +
        '</div>' +
        '<div style="display:flex;gap:12px;">' +
          '<div class="form-group" style="flex:1;">' +
            '<label for="board-write-author">작성자</label>' +
            '<select id="board-write-author" style="padding:9px 12px;border:1px solid var(--border);font-family: NixgonFont, sans-serif;font-size:12px;outline:none;background:var(--bg);color:var(--ink);width:100%;"><option>불러오는 중…</option></select>' +
          '</div>' +
          '<div class="form-group" style="min-width:140px;">' +
            '<label for="board-write-date">퍼블리싱 시각</label>' +
            '<input type="datetime-local" id="board-write-date" class="admin-control-input board-write-datetime" />' +
          '</div>' +
        '</div>' +
        '<div class="form-group">' +
          '<label>글머리 태그</label>' +
          '<div id="board-tag-selector" class="tag-pill-group"><span style="font-size:11px;color:var(--muted);">불러오는 중…</span></div>' +
          '<div class="public-tag-add-tools">' +
            '<input type="text" id="board-tag-new-input" maxlength="30" placeholder="현재 카테고리에 새 태그 추가" />' +
            '<button type="button" id="board-tag-new-btn" class="public-inline-tag-add">태그 추가</button>' +
          '</div>' +
        '</div>' +
        '<div class="form-group">' +
          '<label>대표 이미지</label>' +
          '<div id="board-cover-wrap" class="cover-upload-wrap">' +
            '<button type="button" id="board-cover-btn" class="cover-upload-btn">📷 대표 이미지 선택</button>' +
            '<div id="board-cover-preview"></div>' +
          '</div>' +
          '<input type="text" id="board-write-image-caption" placeholder="사진 출처 또는 캡션 (선택)" maxlength="300" style="margin-top:10px;" />' +
          '<p style="font-size:10px;color:var(--muted);font-family: NixgonFont, sans-serif;margin-top:6px;">대표 사진 아래에 출처 또는 캡션으로 표기됩니다. 본문 이미지는 각 이미지 캡션에 같은 형식으로 표기됩니다.</p>' +
        '</div>' +
        '<div class="form-group">' +
          '<label for="board-write-youtube-input">유튜브 영상 링크</label>' +
          '<input type="url" id="board-write-youtube-input" placeholder="https://www.youtube.com/watch?v=..." maxlength="300" />' +
          '<p style="font-size:10px;color:var(--muted);font-family: NixgonFont, sans-serif;margin-top:6px;">선택 입력입니다. YouTube / youtu.be 링크를 넣으면 기사 페이지와 뷰어에 영상이 표시됩니다.</p>' +
        '</div>' +
        '<div class="form-group">' +
          '<label>본문 * <span style="font-size:10px;color:var(--muted);font-family: NixgonFont, sans-serif;">(본문 이미지는 기사 안에 그대로 표시됩니다)</span></label>' +
          '<div id="board-editorjs" class="board-editorjs-wrap"></div>' +
        '</div>' +
        '<div class="form-group">' +
          '<label>슬라이드 전용 이미지 <span class="admin-label-note" id="board-gallery-count">0/10</span></label>' +
          '<div class="cover-upload-wrap">' +
            '<button type="button" id="board-gallery-btn" class="cover-upload-btn">🖼 슬라이드 이미지 선택</button>' +
            '<div id="board-gallery-preview" class="gallery-upload-preview"><p class="gallery-upload-empty">슬라이드 전용 이미지를 올리면 기사 하단에서만 별도 슬라이드로 노출됩니다.</p></div>' +
          '</div>' +
          '<p style="font-size:10px;color:var(--muted);font-family: NixgonFont, sans-serif;margin-top:6px;">본문 아래 별도 슬라이드로 노출되며 2장 이상일 때만 활성화됩니다.</p>' +
        '</div>' +
        '<details class="location-form-toggle" id="board-location-toggle">' +
          '<summary>위치 정보 추가 (OpenStreetMap)</summary>' +
          '<div class="location-form-fields">' +
            '<div class="form-group">' +
              '<label for="board-write-location-name">위치 이름 <span style="font-size:10px;color:var(--muted);font-family:NixgonFont,sans-serif;">내가 지정하는 이름</span></label>' +
              '<input type="text" id="board-write-location-name" placeholder="예: 강원특별자치도 세계잼버리수련장" maxlength="120" />' +
            '</div>' +
            '<div class="form-group">' +
              '<label for="board-write-location-address">주소 <span style="font-size:10px;color:var(--muted);font-family:NixgonFont,sans-serif;">OpenStreetMap 기준 실주소</span></label>' +
              '<div style="display:flex;gap:8px;align-items:flex-start;">' +
                '<input type="text" id="board-write-location-address" placeholder="예: 강원도 고성군 토성면 ..." maxlength="300" style="flex:1;" />' +
                '<button type="button" id="board-location-check-btn" style="white-space:nowrap;padding:9px 12px;border:1px solid var(--border);background:var(--bg);font-family:NixgonFont,sans-serif;font-size:11px;cursor:pointer;">지도 확인</button>' +
              '</div>' +
              '<p style="font-size:10px;color:var(--muted);font-family:NixgonFont,sans-serif;margin-top:6px;">기사 하단에 접힘형 지도 섹션으로 노출됩니다. 게재 전 반드시 지도 확인을 눌러 위치를 검증하세요.</p>' +
            '</div>' +
            '<div id="board-location-map-preview" style="display:none;margin-top:8px;border:1px solid var(--border);overflow:hidden;">' +
              '<iframe id="board-location-map-frame" style="width:100%;height:200px;border:0;display:block;" loading="lazy"></iframe>' +
              '<div id="board-location-map-status" style="font-size:10px;padding:4px 8px;color:var(--muted);font-family:NixgonFont,sans-serif;"></div>' +
            '</div>' +
          '</div>' +
        '</details>' +
        '<div class="form-group" style="margin-top:24px;border-top:1px solid var(--border);padding-top:20px;">' +
          '<label for="board-write-metatags-input">SEO 해시태그 <span style="font-size:10px;color:var(--muted);font-family: NixgonFont, sans-serif;">(쉼표로 구분 · comma-separated)</span></label>' +
          '<input type="text" id="board-write-metatags-input" placeholder="예: 스카우트, 잼버리, WOSM, 세계스카우트" maxlength="500" />' +
          '<p style="font-size:10px;color:var(--muted);font-family: NixgonFont, sans-serif;margin-top:6px;">검색엔진 최적화를 위한 키워드입니다. 각 게시글의 메타 태그로 사용됩니다.</p>' +
        '</div>' +
        '<div class="form-group" style="display:flex;align-items:center;gap:10px;margin-top:8px;">' +
          '<input type="checkbox" id="board-ai-assisted" style="width:auto;margin:0;" />' +
          '<label for="board-ai-assisted" style="margin:0;cursor:pointer;font-family: NixgonFont, sans-serif;font-size:11px;color:var(--muted);">AI 지원 여부</label>' +
        '</div>' +
        '<div id="board-write-turnstile" style="margin:20px 0 0;"></div>' +
        '<button id="board-write-submit" class="submit-btn" style="margin-top:12px;">게재하기</button>' +
        '<button id="board-write-savedraft" class="cancel-btn visible" style="margin-left:8px;">💾 임시저장</button>' +
        '<button id="board-write-cancel" class="cancel-btn visible">취소</button>' +
      '</div>';
    document.body.appendChild(writeOverlay);

    document.getElementById('board-write-close').addEventListener('click', function () { self._closeWriteForm(); });
    document.getElementById('board-write-cancel').addEventListener('click', function () { self._closeWriteForm(); });
    document.getElementById('board-write-submit').addEventListener('click', function () { self._submitPost(); });
    document.getElementById('board-cover-btn').addEventListener('click', function () { self._uploadCoverImage(); });
    document.getElementById('board-gallery-btn').addEventListener('click', function () { self._uploadGalleryImages(); });
    document.getElementById('board-tag-new-btn').addEventListener('click', function () { self._addWriteTag(); });
    document.getElementById('board-tag-new-input').addEventListener('keydown', function (event) {
      if (event.key === 'Enter') {
        event.preventDefault();
        self._addWriteTag();
      }
    });

    var sfInput = document.getElementById('board-write-special-feature');
    var sfDropdown = document.getElementById('board-sf-dropdown');
    var _sfItems = [];
    function _loadSfItems() {
      if (_sfItems.length) return;
      var currentCategory = self.apiCategory || self.category;
      fetch('/api/posts/special-features?category=' + encodeURIComponent(currentCategory), { cache: 'no-store' })
        .then(function (r) { return r.json(); })
        .then(function (data) { _sfItems = data && Array.isArray(data.items) ? data.items : []; })
        .catch(function () {});
    }
    function _showSfDropdown(filter) {
      var filtered = filter ? _sfItems.filter(function (s) { return s.toLowerCase().indexOf(filter.toLowerCase()) >= 0; }) : _sfItems;
      if (!filtered.length) {
        sfDropdown.style.display = 'none';
        return;
      }
      sfDropdown.innerHTML = filtered.map(function (s) {
        return '<div class="sf-dropdown-item" style="padding:8px 12px;cursor:pointer;font-family:NixgonFont,sans-serif;font-size:12px;border-bottom:1px solid var(--border);">' + GW.escapeHtml(s) + '</div>';
      }).join('');
      sfDropdown.querySelectorAll('.sf-dropdown-item').forEach(function (item) {
        item.addEventListener('click', function () {
          sfInput.value = item.textContent;
          sfDropdown.style.display = 'none';
        });
        item.addEventListener('mouseenter', function () { item.style.background = 'var(--surface)'; });
        item.addEventListener('mouseleave', function () { item.style.background = ''; });
      });
      sfDropdown.style.display = 'block';
    }
    if (sfInput) {
      sfInput.addEventListener('focus', function () {
        _loadSfItems();
        setTimeout(function () { _showSfDropdown(sfInput.value); }, 100);
      });
      sfInput.addEventListener('input', function () { _showSfDropdown(sfInput.value); });
      document.addEventListener('click', function (e) {
        if (!sfInput.contains(e.target) && !sfDropdown.contains(e.target)) {
          sfDropdown.style.display = 'none';
        }
      });
    }

    document.getElementById('board-location-check-btn').addEventListener('click', function () {
      self._checkLocationAddress();
    });
    document.getElementById('board-write-location-address').addEventListener('input', function () {
      var prev = document.getElementById('board-location-map-preview');
      if (prev) prev.style.display = 'none';
    });
    document.getElementById('board-write-savedraft').addEventListener('click', function () {
      self._saveDraft(true);
    });
    writeOverlay.addEventListener('click', function (e) {
      if (e.target === writeOverlay) self._closeWriteForm();
    });
  };

  Board.prototype._renderWriteTagSelector = function (tags) {
    var self = this;
    var sel = document.getElementById('board-tag-selector');
    if (!sel) return;
    var selected = (self._selectedTags || []).filter(function (tag) {
      return tags.indexOf(tag) >= 0;
    });
    self._selectedTags = selected;
    var html = '<button type="button" class="tag-pill' + (!selected.length ? ' active' : '') + '" data-tag="">없음</button>';
    tags.forEach(function (tag) {
      var active = selected.indexOf(tag) >= 0 ? ' active' : '';
      html += '<button type="button" class="tag-pill' + active + '" data-tag="' + GW.escapeHtml(tag) + '">' + GW.escapeHtml(tag) + '</button>';
    });
    sel.innerHTML = html;
    sel.querySelectorAll('.tag-pill').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var tagVal = btn.dataset.tag || '';
        if (tagVal === '') {
          self._selectedTags = [];
        } else {
          var idx = self._selectedTags.indexOf(tagVal);
          if (idx >= 0) self._selectedTags.splice(idx, 1);
          else self._selectedTags.push(tagVal);
        }
        syncBoardTagPills(sel, self._selectedTags);
      });
    });
    syncBoardTagPills(sel, self._selectedTags);
  };

  Board.prototype._loadWriteTagOptions = function () {
    var self = this;
    var sel = document.getElementById('board-tag-selector');
    if (sel) sel.innerHTML = '<span style="font-size:11px;color:var(--muted);">불러오는 중…</span>';
    return fetch('/api/settings/tags?category=' + encodeURIComponent(self.category), { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        self._renderWriteTagSelector((data && data.items) || []);
      })
      .catch(function () {
        if (sel) sel.innerHTML = '<span style="font-size:11px;color:var(--muted);">태그를 불러오지 못했습니다</span>';
      });
  };

  Board.prototype._addWriteTag = function () {
    var self = this;
    var input = document.getElementById('board-tag-new-input');
    var value = (input && input.value || '').trim();
    if (!value) {
      GW.showToast('태그명을 입력해주세요', 'error');
      if (input) input.focus();
      return;
    }
    GW.addManagedTagToCategory(value, self.category)
      .then(function (result) {
        var selectedTag = result && result.selectedTag ? result.selectedTag : value;
        if (self._selectedTags.indexOf(selectedTag) < 0) self._selectedTags.push(selectedTag);
        return self._loadWriteTagOptions().then(function () {
          if (input) input.value = '';
          GW.showToast(result && result.created ? '태그를 추가하고 바로 선택했습니다' : '이미 있는 태그라서 바로 선택했습니다', 'success');
        });
      })
      .catch(function (err) {
        GW.showToast(err && err.message ? err.message : '태그를 추가하지 못했습니다', 'error');
      });
  };

  Board.prototype._checkLocationAddress = function () {
    var addr = (document.getElementById('board-write-location-address') || {}).value || '';
    addr = addr.trim();
    if (!addr) {
      GW.showToast('주소를 입력하세요', 'error');
      return;
    }
    var btn = document.getElementById('board-location-check-btn');
    var prev = document.getElementById('board-location-map-preview');
    var frame = document.getElementById('board-location-map-frame');
    var status = document.getElementById('board-location-map-status');
    btn.disabled = true;
    btn.textContent = '검색 중…';
    prev.style.display = 'none';
    fetch('https://nominatim.openstreetmap.org/search?q=' + encodeURIComponent(addr) + '&format=json&limit=1', {
      headers: { 'Accept-Language': 'ko,en', 'User-Agent': 'GilwellMedia/1.0' }
    })
      .then(function (r) { return r.json(); })
      .then(function (results) {
        btn.disabled = false;
        btn.textContent = '지도 확인';
        if (!results || !results.length) {
          GW.showToast('주소를 지도에서 찾을 수 없습니다. 다른 주소를 사용해보세요.', 'error');
          return;
        }
        var loc = results[0];
        var lat = parseFloat(loc.lat);
        var lon = parseFloat(loc.lon);
        var d = 0.01;
        var bbox = (lon - d) + ',' + (lat - d) + ',' + (lon + d) + ',' + (lat + d);
        frame.src = 'https://www.openstreetmap.org/export/embed.html?bbox=' + bbox + '&layer=mapnik&marker=' + lat + ',' + lon;
        status.textContent = '✓ ' + (loc.display_name || addr);
        prev.style.display = 'block';
      })
      .catch(function () {
        btn.disabled = false;
        btn.textContent = '지도 확인';
        GW.showToast('지도 검색 중 오류가 발생했습니다', 'error');
      });
  };

  Board.prototype._loadEditorJs = function (callback) {
    if (window.EditorJS) {
      callback();
      return;
    }

    function loadScript(src, cb) {
      var s = document.createElement('script');
      s.src = src;
      s.onload = cb;
      document.head.appendChild(s);
    }

    loadScript('https://cdn.jsdelivr.net/npm/@editorjs/editorjs@2.29.1/dist/editorjs.umd.js', function () {
      var pending = 3;
      function done() {
        pending -= 1;
        if (pending === 0) callback();
      }
      loadScript('https://cdn.jsdelivr.net/npm/@editorjs/header@2.8.1/dist/header.umd.js', done);
      loadScript('https://cdn.jsdelivr.net/npm/@editorjs/list@1.10.0/dist/list.umd.js', done);
      loadScript('https://cdn.jsdelivr.net/npm/@editorjs/quote@2.7.5/dist/quote.umd.js', done);
    });
  };

  Board.prototype._initEditorJs = function () {
    if (this._editor) return;

    this._editor = new window.EditorJS({
      holder: 'board-editorjs',
      placeholder: '내용을 작성하세요...',
      tools: {
        paragraph: {
          inlineToolbar: true,
          config: { preserveBlank: true },
        },
        header: {
          class: window.Header,
          config: { levels: [2, 3, 4], defaultLevel: 2 },
        },
        list: {
          class: window.List,
          inlineToolbar: true,
        },
        quote: {
          class: window.Quote,
          inlineToolbar: true,
        },
        image: {
          class: GW.makeEditorImageTool(),
        },
      },
    });
  };

  Board.prototype._showPasswordModal = function () {
    var self = this;
    var overlay = document.getElementById('board-pw-overlay');
    if (!overlay) return;
    document.getElementById('board-pw-input').value = '';
    document.getElementById('board-pw-error').style.display = 'none';
    this._loginTurnstileToken = '';
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
    GW.loadTurnstile(function () {
      if (window.turnstile && GW.TURNSTILE_SITE_KEY) {
        if (self._loginTurnstileWidgetId == null) {
          self._loginTurnstileWidgetId = window.turnstile.render('#board-pw-turnstile', {
            sitekey: GW.TURNSTILE_SITE_KEY,
            theme: 'light',
            callback: function (token) { self._loginTurnstileToken = token; },
            'expired-callback': function () { self._loginTurnstileToken = ''; },
          });
        } else {
          window.turnstile.reset(self._loginTurnstileWidgetId);
        }
      }
    });
    setTimeout(function () { document.getElementById('board-pw-input').focus(); }, 50);
  };

  Board.prototype._closePasswordModal = function () {
    var overlay = document.getElementById('board-pw-overlay');
    if (overlay) overlay.classList.remove('open');
    document.body.style.overflow = '';
    this._loginTurnstileToken = '';
    if (window.turnstile && this._loginTurnstileWidgetId != null) {
      window.turnstile.reset(this._loginTurnstileWidgetId);
    }
  };

  Board.prototype._checkPassword = function () {
    var self = this;
    var input = document.getElementById('board-pw-input');
    var submitBtn = document.getElementById('board-pw-submit');
    var error = document.getElementById('board-pw-error');
    var pw = (input.value || '').trim();
    if (!pw) return;
    if (GW.TURNSTILE_SITE_KEY && !this._loginTurnstileToken) {
      error.textContent = 'CAPTCHA를 완료해주세요';
      error.style.display = 'block';
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = '확인 중…';
    error.style.display = 'none';

    GW.apiFetch('/api/admin/login', {
      method: 'POST',
      body: JSON.stringify({
        password: pw,
        cf_turnstile_response: this._loginTurnstileToken || undefined,
      }),
    })
      .then(function (data) {
        GW.setToken(data.token);
        if (GW.setAdminRole) GW.setAdminRole(data.role || 'full');
        self._closePasswordModal();
        self._showWriteForm();
      })
      .catch(function (err) {
        error.textContent = err && err.message ? err.message : '관리자만 글을 쓸 수 있습니다';
        error.style.display = 'block';
        input.value = '';
        input.focus();
        self._loginTurnstileToken = '';
        if (window.turnstile && self._loginTurnstileWidgetId != null) {
          window.turnstile.reset(self._loginTurnstileWidgetId);
        }
      })
      .finally(function () {
        submitBtn.disabled = false;
        submitBtn.textContent = '확인';
      });
  };

  Board.prototype._uploadCoverImage = function () {
    var self = this;
    var input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = function () {
      var file = input.files[0];
      if (!file) return;
      GW.optimizeImageFile(file, { maxW: 1600, maxH: 1600, quality: 0.82 })
        .then(function (result) {
          self._coverImage = result.dataUrl;
          self._renderCoverPreview();
        })
        .catch(function (err) {
          GW.showToast(err && err.message ? err.message : '이미지 최적화 실패', 'error');
        });
    };
    input.click();
  };

  Board.prototype._uploadGalleryImages = function () {
    var self = this;
    var input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.multiple = true;
    input.onchange = function () {
      var files = Array.prototype.slice.call(input.files || []);
      var remaining = Math.max(0, 10 - self._galleryImages.length);
      if (!files.length) return;
      if (!remaining) {
        GW.showToast('슬라이드 이미지는 최대 10장까지 추가할 수 있습니다', 'error');
        return;
      }
      files.slice(0, remaining).reduce(function (chain, file) {
        return chain.then(function () {
          return GW.optimizeImageFile(file, { maxW: 1800, maxH: 1800, quality: 0.84 }).then(function (result) {
            self._galleryImages.push({ url: result.dataUrl, caption: '' });
          });
        });
      }, Promise.resolve()).then(function () {
        self._renderGalleryPreview();
      }).catch(function (err) {
        GW.showToast(err && err.message ? err.message : '이미지 최적화 실패', 'error');
      });
    };
    input.click();
  };

  Board.prototype._showWriteForm = function () {
    var self = this;
    var overlay = document.getElementById('board-write-overlay');
    if (!overlay) return;
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';

    self._selectedTags = [];
    self._coverImage = null;
    self._galleryImages = [];
    self._turnstileToken = '';
    var coverCaptionEl = document.getElementById('board-write-image-caption');
    if (coverCaptionEl) coverCaptionEl.value = '';
    self._renderCoverPreview();
    self._renderGalleryPreview();
    var aiChk = document.getElementById('board-ai-assisted');
    if (aiChk) aiChk.checked = false;

    var _fillAuthorSelect = function (editors) {
      var sel = document.getElementById('board-write-author');
      if (!sel) return;
      var current = sel.value || 'Editor A';
      sel.innerHTML = GW.buildEditorOptions(editors);
      sel.value = current;
    };
    GW.apiFetch('/api/settings/editors')
      .then(function (data) { _fillAuthorSelect(data.editors || {}); })
      .catch(function () { _fillAuthorSelect({}); });

    var dateEl = document.getElementById('board-write-date');
    if (dateEl) dateEl.value = GW.getKstDateTimeInputValue();

    self._loadWriteTagOptions();

    this._loadEditorJs(function () {
      if (self._editor) {
        self._editor.destroy();
        self._editor = null;
        var holder = document.getElementById('board-editorjs');
        if (holder) holder.innerHTML = '';
      }
      self._initEditorJs();
      document.getElementById('board-write-title-input').value = '';
      var sub = document.getElementById('board-write-subtitle-input');
      if (sub) sub.value = '';
      var sf = document.getElementById('board-write-special-feature');
      if (sf) sf.value = '';
      var mt = document.getElementById('board-write-metatags-input');
      if (mt) mt.value = '';
      var yt = document.getElementById('board-write-youtube-input');
      if (yt) yt.value = '';
      var locationNameEl = document.getElementById('board-write-location-name');
      if (locationNameEl) locationNameEl.value = '';
      var locationAddressEl = document.getElementById('board-write-location-address');
      if (locationAddressEl) locationAddressEl.value = '';
      var locationToggle = document.getElementById('board-location-toggle');
      if (locationToggle) locationToggle.open = false;

      var draftKey = 'gw_draft_' + self.category;
      var draftStr = localStorage.getItem(draftKey);
      if (draftStr) {
        try {
          var draft = JSON.parse(draftStr);
          if (draft && (draft.title || draft.editorData) && confirm('저장된 임시 글이 있습니다. 불러올까요?')) {
            if (draft.title) document.getElementById('board-write-title-input').value = draft.title;
            var sub2 = document.getElementById('board-write-subtitle-input');
            if (sub2 && draft.subtitle) sub2.value = draft.subtitle;
            var sf2 = document.getElementById('board-write-special-feature');
            if (sf2 && draft.special_feature) sf2.value = draft.special_feature;
            var mt2 = document.getElementById('board-write-metatags-input');
            if (mt2 && draft.meta_tags) mt2.value = draft.meta_tags;
            var yt2 = document.getElementById('board-write-youtube-input');
            if (yt2 && draft.youtube_url) yt2.value = draft.youtube_url;
            var locationName2 = document.getElementById('board-write-location-name');
            if (locationName2 && draft.location_name) locationName2.value = draft.location_name;
            var locationAddress2 = document.getElementById('board-write-location-address');
            if (locationAddress2 && draft.location_address) locationAddress2.value = draft.location_address;
            var locationToggle2 = document.getElementById('board-location-toggle');
            if (locationToggle2) locationToggle2.open = !!(draft.location_name || draft.location_address);
            var cap2 = document.getElementById('board-write-image-caption');
            if (cap2) cap2.value = draft.image_caption || '';
            var author2 = document.getElementById('board-write-author');
            if (author2 && draft.author) author2.value = draft.author;
            var date2 = document.getElementById('board-write-date');
            if (date2) date2.value = GW.toDatetimeLocalValue(draft.publish_at || draft.publish_date || '') || GW.getKstDateTimeInputValue();
            var ai2 = document.getElementById('board-ai-assisted');
            if (ai2) ai2.checked = !!draft.ai_assisted;
            if (draft.tags && Array.isArray(draft.tags)) self._selectedTags = draft.tags;
            self._coverImage = draft.image_url || null;
            self._renderCoverPreview();
            self._galleryImages = self._parseGallerySeed(draft.gallery_images);
            self._renderGalleryPreview();
            var tagSel = document.getElementById('board-tag-selector');
            if (tagSel) syncBoardTagPills(tagSel, self._selectedTags);
            if (draft.editorData && self._editor) {
              self._editor.render(draft.editorData).catch(function () {});
            }
          }
        } catch (e) {
          localStorage.removeItem(draftKey);
        }
      }

      setTimeout(function () { document.getElementById('board-write-title-input').focus(); }, 100);
    });

    GW.loadTurnstile(function () {
      if (window.turnstile && GW.TURNSTILE_SITE_KEY) {
        if (self._turnstileWidgetId == null) {
          self._turnstileWidgetId = window.turnstile.render('#board-write-turnstile', {
            sitekey: GW.TURNSTILE_SITE_KEY,
            theme: 'light',
            callback: function (token) { self._turnstileToken = token; },
            'expired-callback': function () { self._turnstileToken = ''; },
          });
        } else {
          window.turnstile.reset(self._turnstileWidgetId);
          self._turnstileToken = '';
        }
      }
    });

    self._startDraftAutosave();
  };

  Board.prototype._closeWriteForm = function () {
    this._stopDraftAutosave();
    var overlay = document.getElementById('board-write-overlay');
    if (overlay) overlay.classList.remove('open');
    document.body.style.overflow = '';
    this._turnstileToken = '';
    if (window.turnstile && this._turnstileWidgetId != null) {
      window.turnstile.reset(this._turnstileWidgetId);
    }
  };

  Board.prototype._submitPost = function () {
    var self = this;
    var title = (document.getElementById('board-write-title-input').value || '').trim();
    var subEl = document.getElementById('board-write-subtitle-input');
    var subtitle = subEl ? (subEl.value || '').trim() : '';
    var specialFeatureEl = document.getElementById('board-write-special-feature');
    var mtEl = document.getElementById('board-write-metatags-input');
    var metaTags = mtEl ? (mtEl.value || '').trim() : '';
    var ytEl = document.getElementById('board-write-youtube-input');
    var youtubeUrl = ytEl ? (ytEl.value || '').trim() : '';
    var coverCaptionEl = document.getElementById('board-write-image-caption');
    var locationNameEl = document.getElementById('board-write-location-name');
    var locationAddressEl = document.getElementById('board-write-location-address');
    var submitBtn = document.getElementById('board-write-submit');

    if (!title) {
      GW.showToast('제목을 입력해주세요', 'error');
      return;
    }
    if (!this._editor) {
      GW.showToast('에디터가 준비되지 않았습니다', 'error');
      return;
    }
    if (GW.TURNSTILE_SITE_KEY && !this._turnstileToken) {
      GW.showToast('CAPTCHA를 완료해주세요', 'error');
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = '게재 중…';

    this._editor.save()
      .then(function (outputData) {
        var validation = GW.validatePostEditorOutput(outputData);
        if (!validation.ok) {
          GW.showToast(validation.error, 'error');
          submitBtn.disabled = false;
          submitBtn.textContent = '게재하기';
          return;
        }

        GW.apiFetch('/api/posts', {
          method: 'POST',
          body: JSON.stringify({
            category: self.category,
            title: title,
            subtitle: subtitle || null,
            special_feature: specialFeatureEl ? ((specialFeatureEl.value || '').trim() || null) : null,
            content: JSON.stringify(outputData),
            image_url: self._coverImage || null,
            gallery_images: self._galleryImages || [],
            image_caption: coverCaptionEl ? ((coverCaptionEl.value || '').trim() || null) : null,
            youtube_url: youtubeUrl || null,
            location_name: locationNameEl ? ((locationNameEl.value || '').trim() || null) : null,
            location_address: locationAddressEl ? ((locationAddressEl.value || '').trim() || null) : null,
            tag: self._selectedTags && self._selectedTags.length ? self._selectedTags.join(',') : null,
            meta_tags: metaTags || null,
            author: (document.getElementById('board-write-author') || {}).value || undefined,
            publish_at: (document.getElementById('board-write-date') || {}).value ? GW.normalizePublishAtValue(document.getElementById('board-write-date').value) : undefined,
            ai_assisted: (document.getElementById('board-ai-assisted') || {}).checked ? 1 : 0,
            cf_turnstile_response: self._turnstileToken || undefined,
          }),
        })
          .then(function () {
            GW.showToast('게재됐습니다', 'success');
            localStorage.removeItem('gw_draft_' + self.category);
            self._stopDraftAutosave();
            self._turnstileToken = '';
            if (window.turnstile && self._turnstileWidgetId != null) {
              window.turnstile.reset(self._turnstileWidgetId);
            }
            self._closeWriteForm();
            self.page = 1;
            self.total = 0;
            self.totalPages = 1;
            self.gridEl.innerHTML = '';
            self._load();
          })
          .catch(function (err) {
            if (err.status === 401) {
              GW.clearToken();
              GW.showToast('세션이 만료됐습니다. 다시 로그인해주세요.', 'error');
              self._closeWriteForm();
            } else {
              GW.showToast(err.message || '게재 실패', 'error');
              self._turnstileToken = '';
              if (window.turnstile && self._turnstileWidgetId != null) {
                window.turnstile.reset(self._turnstileWidgetId);
              }
            }
          })
          .finally(function () {
            submitBtn.disabled = false;
            submitBtn.textContent = '게재하기';
          });
      })
      .catch(function () {
        GW.showToast('내용 저장 중 오류가 발생했습니다', 'error');
        submitBtn.disabled = false;
        submitBtn.textContent = '게재하기';
      });
  };

  Board.prototype._saveDraft = function (showToast) {
    var self = this;
    var key = 'gw_draft_' + this.category;
    var title = (document.getElementById('board-write-title-input') || {}).value || '';
    var subEl = document.getElementById('board-write-subtitle-input');
    var subtitle = subEl ? (subEl.value || '') : '';
    var specialFeatureEl = document.getElementById('board-write-special-feature');
    var mtEl = document.getElementById('board-write-metatags-input');
    var metaTags = mtEl ? (mtEl.value || '') : '';
    var ytEl = document.getElementById('board-write-youtube-input');
    var youtubeUrl = ytEl ? (ytEl.value || '') : '';
    var coverCaptionEl = document.getElementById('board-write-image-caption');
    var locationNameEl = document.getElementById('board-write-location-name');
    var locationAddressEl = document.getElementById('board-write-location-address');
    var authEl = document.getElementById('board-write-author');
    var dateEl = document.getElementById('board-write-date');
    var aiEl = document.getElementById('board-ai-assisted');
    var saving = {
      title: title,
      subtitle: subtitle,
      special_feature: specialFeatureEl ? (specialFeatureEl.value || '') : '',
      meta_tags: metaTags,
      youtube_url: youtubeUrl,
      image_caption: coverCaptionEl ? (coverCaptionEl.value || '') : '',
      location_name: locationNameEl ? (locationNameEl.value || '') : '',
      location_address: locationAddressEl ? (locationAddressEl.value || '') : '',
      author: authEl ? (authEl.value || '') : '',
      publish_at: dateEl ? GW.normalizePublishAtValue(dateEl.value || '') : '',
      ai_assisted: aiEl ? !!aiEl.checked : false,
      image_url: self._coverImage || null,
      gallery_images: self._galleryImages || [],
      tags: self._selectedTags || [],
    };

    function storeSaving() {
      localStorage.setItem(key, JSON.stringify(saving));
      if (showToast) GW.showToast('임시저장됐습니다', 'success');
    }

    if (self._editor) {
      return self._editor.save().then(function (d) {
        saving.editorData = d;
        storeSaving();
      }).catch(function () {
        if (showToast) GW.showToast('임시저장 실패', 'error');
      });
    }
    storeSaving();
    return Promise.resolve();
  };

  Board.prototype._startDraftAutosave = function () {
    var self = this;
    this._draftTimer = setInterval(function () {
      var title = (document.getElementById('board-write-title-input') || {}).value || '';
      var subtitle = ((document.getElementById('board-write-subtitle-input') || {}).value || '');
      if (!title && !subtitle) return;
      self._saveDraft(false);
    }, 30000);
  };

  Board.prototype._stopDraftAutosave = function () {
    if (this._draftTimer) {
      clearInterval(this._draftTimer);
      this._draftTimer = null;
    }
  };

  Board.prototype._renderCoverPreview = function () {
    var self = this;
    var preview = document.getElementById('board-cover-preview');
    if (!preview) return;
    if (!self._coverImage) {
      preview.innerHTML = '';
      return;
    }
    preview.innerHTML =
      '<img src="' + self._coverImage + '" class="cover-preview-img">' +
      '<button type="button" class="cover-remove-btn" id="board-cover-remove">× 제거</button>';
    document.getElementById('board-cover-remove').addEventListener('click', function () {
      self._coverImage = null;
      preview.innerHTML = '';
    });
  };

  Board.prototype._renderGalleryPreview = function () {
    var self = this;
    var preview = document.getElementById('board-gallery-preview');
    var counter = document.getElementById('board-gallery-count');
    if (counter) counter.textContent = String(self._galleryImages.length) + '/10';
    if (!preview) return;
    if (!self._galleryImages.length) {
      preview.innerHTML = '<p class="gallery-upload-empty">슬라이드 전용 이미지를 올리면 기사 하단에서만 별도 슬라이드로 노출됩니다.</p>';
      return;
    }
    preview.innerHTML = self._galleryImages.map(function (item, index) {
      return '<div class="gallery-upload-item">' +
        '<img src="' + item.url + '" class="gallery-upload-thumb" alt="슬라이드 이미지 ' + (index + 1) + '">' +
        '<button type="button" class="gallery-upload-remove" data-index="' + index + '">제거</button>' +
      '</div>';
    }).join('');
    preview.querySelectorAll('.gallery-upload-remove').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var index = parseInt(btn.getAttribute('data-index') || '-1', 10);
        if (!Number.isFinite(index) || index < 0) return;
        self._galleryImages.splice(index, 1);
        self._renderGalleryPreview();
      });
    });
  };

  Board.prototype._parseGallerySeed = function (raw) {
    if (!raw) return [];
    if (Array.isArray(raw)) return raw.slice(0, 10);
    try {
      var parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed.slice(0, 10) : [];
    } catch (_) {
      return [];
    }
  };
})();
