import { verifyTokenRole, extractToken } from '../../_shared/auth.js';
import { gateMenuAccess } from '../../_shared/admin-permissions.js';
import { loadNavLabels, normalizeNavLabels } from '../../_shared/nav-labels.js';
import { recordSettingChange } from '../../_shared/settings-audit.js';

export async function onRequestGet({ env }) {
  try {
    const labels = await loadNavLabels(env);
    return json({ labels }, 200, publicCacheHeaders(300, 1800));
  } catch (err) {
    console.error('GET /api/settings/nav-labels error:', err);
    return json({ labels: normalizeNavLabels({}) }, 200, publicCacheHeaders(300, 1800));
  }
}

export async function onRequestPut({ request, env }) {
  const __gate = await gateMenuAccess(request, env, 'translations', 'view'); if (__gate) return __gate

  let body;
  try { body = await request.json(); } catch {
    return json({ error: 'Invalid JSON body' }, 400);
  }

  const labels = normalizeNavLabels(body && body.labels);

  try {
    const prevRow = await env.DB.prepare(`SELECT value FROM settings WHERE key = 'nav_labels'`).first();
    await env.DB.prepare(
      `INSERT INTO settings (key, value) VALUES ('nav_labels', ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`
    ).bind(JSON.stringify(labels)).run();
    await recordSettingChange(env, {
      key: 'nav_labels',
      previousValue: prevRow && prevRow.value,
      path: '/api/settings/nav-labels',
      message: '메뉴명 설정 변경',
      details: { labels: labels },
    });
    return json({ labels });
  } catch (err) {
    console.error('PUT /api/settings/nav-labels error:', err);
    return json({ error: 'Database error' }, 500);
  }
}

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: Object.assign({ 'Content-Type': 'application/json' }, extraHeaders),
  });
}

function publicCacheHeaders(maxAge, swr) {
  return {
    'Cache-Control': `public, max-age=${maxAge}, s-maxage=${maxAge}, stale-while-revalidate=${swr}`,
  };
}
