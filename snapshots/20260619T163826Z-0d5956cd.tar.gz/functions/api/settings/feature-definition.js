import { extractToken, verifyTokenRole } from '../../_shared/auth.js';
import { gateMenuAccess } from '../../_shared/admin-permissions.js';
import { loadFeatureDefinition, DEFAULT_FEATURE_DEFINITION, normalizeFeatureDefinitionContent } from '../../_shared/feature-definition.js';
import { recordSettingChange } from '../../_shared/settings-audit.js';

export async function onRequestGet({ env }) {
  try {
    const [content, updatedRow] = await Promise.all([
      loadFeatureDefinition(env),
      env.DB.prepare(
        `SELECT saved_at FROM settings_history WHERE key = 'feature_definition' ORDER BY saved_at DESC LIMIT 1`
      ).first().catch(() => null),
    ]);
    const updated_at = updatedRow && updatedRow.saved_at ? String(updatedRow.saved_at) : null;
    return json({ content, updated_at }, 200);
  } catch (err) {
    console.error('GET /api/settings/feature-definition error:', err);
    return json({ content: DEFAULT_FEATURE_DEFINITION, error: 'Database error' }, 500);
  }
}

export async function onRequestPut({ request, env }) {
  // 보안: 운영 원본(KMS) 편집은 write 권한 필수. 과거 'view' 로 게이팅돼 보기 권한만 있는
  // 멤버가 KMS 를 수정할 수 있었던 결함 교정. write 액션은 분당 60회 rate-limit 도 함께 적용된다.
  const __gate = await gateMenuAccess(request, env, 'kms', 'write'); if (__gate) return __gate
  let body;
  try { body = await request.json(); } catch (_) { return json({ error: 'Invalid JSON' }, 400); }
  const content = normalizeFeatureDefinitionContent(body && body.content || '').trim();
  if (!content) return json({ error: '기능 정의서 내용이 비어 있습니다.' }, 400);
  try {
    const prevRow = await env.DB.prepare(`SELECT value FROM settings WHERE key = 'feature_definition'`).first();
    await env.DB.prepare(
      `INSERT INTO settings (key, value) VALUES ('feature_definition', ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`
    ).bind(content).run();
    await recordSettingChange(env, {
      key: 'feature_definition',
      previousValue: prevRow && prevRow.value,
      path: '/api/settings/feature-definition',
      message: '기능 정의서 설정 변경',
    });
    return json({ ok: true, content }, 200);
  } catch (err) {
    console.error('PUT /api/settings/feature-definition error:', err);
    return json({ error: 'Database error' }, 500);
  }
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}
