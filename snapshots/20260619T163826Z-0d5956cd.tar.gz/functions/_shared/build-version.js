// AUTO-MANAGED — values are rewritten by scripts/sync_versions.sh on every
// release. Do not edit by hand; bump VERSION / ADMIN_VERSION / ASSET_VERSION
// files instead and run ./scripts/sync_versions.sh.
export const SITE_VERSION = '00.172.00';
export const ADMIN_VERSION = '03.150.00';
export const ASSET_VERSION = '20260619163253';
