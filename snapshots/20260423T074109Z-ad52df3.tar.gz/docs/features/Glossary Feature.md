---
tags: [feature, public, homepage, glossary]
aliases: [Glossary Feature, 용어집]
scope: homepage
---
# Glossary Feature

## 기능 역할

- 용어 목록
- 용어 검색
- 일부 로그인 액션

## 연결 모듈

- [[Glossary Runtime]]
- [[Public Site Chrome]]

## 연결 템플릿

- [[Glossary Template]]

## 연결 surface

- [[Glossary Surface]]

## 연결 API

- [[Settings API]]
- [[Admin Session API]]
