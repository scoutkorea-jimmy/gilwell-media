import { buildShareMetaBlock, getResolvedShareImage, getSitePageKey, loadSiteMeta } from './_shared/site-meta.js';
import { selectHomeRailIds, hydrateByIds } from './_shared/home-rails.js';
import { serializePostImage } from './_shared/images.js';
import { loadNavLabels, getNavLabel } from './_shared/nav-labels.js';
import { ensureDuePostsPublished } from './_shared/publish-due-posts.js';
import { getPostExcerpt } from './_shared/post-excerpt.js';

const PUBLIC_DATE_EXPR = "CASE WHEN publish_at IS NOT NULL AND trim(publish_at) <> '' THEN CASE WHEN instr(publish_at, 'Z') > 0 OR instr(substr(publish_at, 11), '+') > 0 THEN datetime(replace(publish_at, 'T', ' '), '+9 hours') ELSE datetime(replace(publish_at, 'T', ' ')) END ELSE CASE WHEN created_at IS NOT NULL AND trim(created_at) <> '' THEN datetime(replace(created_at, 'T', ' '), '+9 hours') ELSE NULL END END";

export async function onRequest(context) {
  const { request, env } = context;
  const url = new URL(request.url);
  const pageKey = getSitePageKey(url.pathname);

  // 자동 게시 트리거는 (1) HTML 페이지 요청에만 (2) waitUntil 로 비차단 실행.
  // /js/*, /css/*, /img/* 등 정적 자산은 [[path]] catch-all 에 매칭되긴 하지만
  // 자동 게시 로직을 돌릴 필요가 없다 — DB 라운드트립이 Worker CPU 한도(1102)
  // 를 갉아먹어 정적 자산이 간헐적 503 으로 응답되는 회귀(2026-05-26 발견)를
  // 방지. 페이지 요청에서도 await 로 응답 시간을 늘리는 대신 waitUntil 로
  // 다음 요청까지만 결과가 반영되도록 한다.
  if (pageKey && typeof context.waitUntil === 'function') {
    context.waitUntil(
      ensureDuePostsPublished(env, url.origin).catch((err) => {
        console.error('[[path]] auto publish error:', err);
      })
    );
  }

  const response = await context.next();
  if (!pageKey) return response;

  const contentType = response.headers.get('content-type') || '';
  if (!contentType.includes('text/html')) return response;

  const html = await response.text();
  const siteMeta = await loadSiteMeta(env);
  // navLabels 는 한 번만 읽어 (1) 부트스트랩 주입과 (2) 홈 SSR 양쪽이 공유한다.
  // 이전에는 loadHomeSsrContent 안에서만 읽어 클라이언트가 /api/home 응답 전까지
  // 라벨을 알 수 없었고, 그 탓에 nav 노출이 /api/home 성공에 묶여 있었다.
  // 프로미스를 그대로 넘겨 기존 병렬성은 유지한다.
  const navLabelsPromise = loadNavLabels(env).catch(() => ({}));
  const [translationStrings, publicRuntime, homeSsr, pageExtraSchema, navLabels] = await Promise.all([
    loadTranslationStrings(env),
    loadPublicRuntime(env),
    pageKey === 'home' ? loadHomeSsrContent(env, url.origin, navLabelsPromise) : Promise.resolve(null),
    loadPageExtraSchema(env, url.origin, pageKey),
    navLabelsPromise,
  ]);
  const pageMeta = siteMeta.pages[pageKey] || siteMeta.pages.home;
  const canonicalPath = getCanonicalPath(url.pathname, pageKey);
  const itemListElements = await loadPageItemList(env, url.origin, pageKey);
  const shareMeta = buildShareMetaBlock({
    pageKey,
    title: pageMeta.title,
    description: pageMeta.description,
    url: url.origin + canonicalPath,
    imageUrl: getResolvedShareImage(siteMeta, url.origin),
    googleVerification: siteMeta.google_verification,
    naverVerification: siteMeta.naver_verification,
    itemListElements,
  });

  const updated = html
    .replace(/<title>[\s\S]*?<\/title>/, `<title>${escapeHtml(pageMeta.title)}</title>`)
    .replace('<!-- SHARE_META -->', shareMeta + pageExtraSchema);

  const headers = new Headers(response.headers);
  headers.set('Content-Type', 'text/html; charset=UTF-8');
  let baseResponse = new Response(updated, {
    status: response.status,
    statusText: response.statusText,
    headers,
  });
  if (pageKey === 'home' && homeSsr) {
    baseResponse = applyHomeSsrContent(baseResponse, homeSsr);
  }
  return applyTranslationBootstrap(baseResponse, translationStrings, publicRuntime, navLabels);
}

function getCanonicalPath(pathname, pageKey) {
  if (pathname === '/index.html' || pathname === '/') return '/';
  if (pageKey === 'latest') return '/latest';
  if (pageKey === 'jamboree16') return '/jamboree16';
  if (pageKey === 'korea') return '/korea';
  if (pageKey === 'apr') return '/apr';
  if (pageKey === 'wosm') return '/wosm';
  if (pageKey === 'wosm_members') return '/wosm-members';
  if (pageKey === 'people') return '/people';
  if (pageKey === 'glossary') return '/glossary';
  if (pageKey === 'calendar') return '/calendar';
  return pathname;
}

async function loadPageItemList(env, origin, pageKey) {
  if (!['home', 'latest', 'korea', 'apr', 'wosm', 'people', 'glossary'].includes(pageKey)) return [];
  try {
    const category = pageKey === 'home' || pageKey === 'latest' ? null : pageKey;
    const query = category
      ? `SELECT id, title FROM posts WHERE published = 1 AND category = ? ORDER BY datetime(COALESCE(publish_at, created_at)) DESC, id DESC LIMIT 10`
      : pageKey === 'latest'
        ? `SELECT id, title FROM posts WHERE published = 1 AND datetime(COALESCE(publish_at, created_at)) >= datetime('now', '-30 days') ORDER BY datetime(COALESCE(publish_at, created_at)) DESC, id DESC LIMIT 10`
        : `SELECT id, title FROM posts WHERE published = 1 ORDER BY datetime(COALESCE(publish_at, created_at)) DESC, id DESC LIMIT 10`;
    const result = category
      ? await env.DB.prepare(query).bind(category).all()
      : await env.DB.prepare(query).all();
    return (result.results || []).map((item) => ({
      url: `${origin}/post/${item.id}`,
      title: item.title || `post-${item.id}`,
    }));
  } catch (err) {
    console.error('[path] DB query failed for page:', pageKey, err);
    return [];
  }
}

// Page-specific schema.org JSON-LD appended after the shared meta block.
// Currently covers:
//   - /glossary       → DefinedTermSet with every term (ko/en/fr + 설명)
//   - /wosm-members   → Dataset describing the member-country table
// Returns "" for pages without extra schema so concatenation stays cheap.
async function loadPageExtraSchema(env, origin, pageKey) {
  if (!pageKey) return '';
  try {
    if (pageKey === 'glossary') return await buildGlossarySchema(env, origin);
    if (pageKey === 'wosm_members') return await buildWosmMembersSchema(env, origin);
  } catch (err) {
    console.error('[path] extra schema build failed for', pageKey, err);
  }
  return '';
}

async function buildGlossarySchema(env, origin) {
  const rs = await env.DB.prepare(
    `SELECT id, bucket, term_ko, term_en, term_fr, description_ko
       FROM glossary_terms
       ORDER BY bucket, COALESCE(sort_order, 0), term_ko`
  ).all();
  const rows = Array.isArray(rs && rs.results) ? rs.results : [];
  if (!rows.length) return '';
  const termList = rows.map((row) => {
    const names = [row.term_ko, row.term_en, row.term_fr].filter(Boolean).map((v) => String(v).trim()).filter(Boolean);
    const primary = names[0] || '';
    const alternates = names.slice(1);
    const entry = {
      '@type': 'DefinedTerm',
      '@id': `${origin}/glossary#term-${row.id}`,
      name: primary,
      inDefinedTermSet: `${origin}/glossary`,
    };
    if (alternates.length) entry.alternateName = alternates;
    const desc = String(row.description_ko || '').trim();
    if (desc) entry.description = desc;
    if (row.bucket) entry.termCode = row.bucket;
    return entry;
  });
  const termSet = {
    '@context': 'https://schema.org',
    '@type': 'DefinedTermSet',
    '@id': `${origin}/glossary`,
    name: 'BP미디어 스카우팅 용어집',
    description: '한국어·영어·프랑스어 스카우팅 용어 사전. WOSM·APR·한국스카우트연맹 공식 표기 기준.',
    url: `${origin}/glossary`,
    inLanguage: ['ko-KR', 'en', 'fr'],
    hasDefinedTerm: termList,
    publisher: { '@type': 'Organization', name: 'BP미디어', url: origin },
  };
  return `\n<script type="application/ld+json">${safeJsonForScript(termSet)}</script>`;
}

async function buildWosmMembersSchema(env, origin) {
  // Count active member countries from the settings-backed blob. Kept as a
  // Dataset (not an ItemList) because AI systems treat Datasets as citable
  // source data for fact-check answers about WOSM membership.
  let memberCount = 0;
  try {
    const row = await env.DB.prepare(
      `SELECT value FROM settings WHERE key = 'wosm_members_items'`
    ).first();
    if (row && row.value) {
      const parsed = JSON.parse(row.value);
      if (Array.isArray(parsed)) memberCount = parsed.length;
      else if (Array.isArray(parsed && parsed.items)) memberCount = parsed.items.length;
    }
  } catch (_) {
    memberCount = 0;
  }
  const dataset = {
    '@context': 'https://schema.org',
    '@type': 'Dataset',
    '@id': `${origin}/wosm-members`,
    name: '세계스카우트연맹(WOSM) 회원국 현황',
    alternateName: 'WOSM Member Countries Dataset',
    description: '세계스카우트연맹 가입 회원 연맹 목록과 국가·지역연맹·가입 연도·등록 규모 등 구조화 데이터. 한국어·영어 명칭 병기.',
    url: `${origin}/wosm-members`,
    inLanguage: ['ko-KR', 'en'],
    isAccessibleForFree: true,
    license: `${origin}/editorial-policy`,
    keywords: ['WOSM', '세계스카우트연맹', 'World Organization of the Scout Movement', '회원국', '지역연맹', 'Asia-Pacific', 'Europe', 'Africa'],
    creator: { '@type': 'Organization', name: 'BP미디어', url: origin },
    publisher: { '@type': 'Organization', name: 'BP미디어', url: origin },
    variableMeasured: [
      { '@type': 'PropertyValue', name: '등록 연맹 수', value: memberCount || undefined },
      { '@type': 'PropertyValue', name: '국가명(한글)', description: 'country_ko' },
      { '@type': 'PropertyValue', name: '국가명(영문)', description: 'country_en' },
      { '@type': 'PropertyValue', name: '국가명(불어)', description: 'country_fr' },
      { '@type': 'PropertyValue', name: '지역연맹', description: 'WOSM 6개 지역 분류' },
      { '@type': 'PropertyValue', name: '가입 연도', description: '세계연맹 가입 연도' },
      { '@type': 'PropertyValue', name: '등록 회원 수', description: 'Census-reported scout count' },
    ],
  };
  return `\n<script type="application/ld+json">${safeJsonForScript(dataset)}</script>`;
}

function safeJsonForScript(value) {
  return JSON.stringify(value)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/&/g, '\\u0026');
}

async function loadTranslationStrings(env) {
  try {
    const row = await env.DB.prepare(`SELECT value FROM settings WHERE key = 'translations'`).first();
    return normalizeTranslationStrings(row ? JSON.parse(row.value || '{}') : {});
  } catch {
    return {};
  }
}

function applyTranslationBootstrap(response, strings, runtime, navLabels) {
  const safeStrings = strings && typeof strings === 'object' ? strings : {};
  const safeRuntime = runtime && typeof runtime === 'object' ? runtime : {};
  // GW_BOOT_NAV_LABELS 가 있어야 site-chrome.js 가 첫 스크립트 실행 시점에 정확한
  // 라벨로 nav 를 그릴 수 있다. 없으면 GW.STRINGS 기본값으로 그렸다가 데이터
  // 도착 후 교체돼 영문 라벨이 한 번 바뀌어 보인다.
  const safeNavLabels = navLabels && typeof navLabels === 'object' ? navLabels : {};
  const bootstrap = `<script>window.GW_BOOT_CUSTOM_STRINGS=${serializeForInlineScript(safeStrings)};window.GW_BOOT_NAV_LABELS=${serializeForInlineScript(safeNavLabels)};window.GW_BOOT_RUNTIME=${serializeForInlineScript(safeRuntime)};window.GW_KAKAO_JS_KEY=${serializeForInlineScript(String(safeRuntime.kakao_js_key || ''))};</script>`;
  return new HTMLRewriter()
    .on('head', {
      element(element) {
        element.append(bootstrap, { html: true });
      }
    })
    .on('[data-i18n]', {
      element(element) {
        const key = element.getAttribute('data-i18n');
        if (!key) return;
        const entry = safeStrings[key];
        if (!entry || typeof entry.ko === 'undefined') return;
        element.setInnerContent(String(entry.ko), {
          html: false,
        });
      }
    })
    .transform(response);
}

async function loadPublicRuntime(env) {
  try {
    const row = await env.DB.prepare(`SELECT value FROM settings WHERE key = 'public_runtime'`).first();
    const parsed = row ? JSON.parse(row.value || '{}') : {};
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function serializeForInlineScript(value) {
  return JSON.stringify(value)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/&/g, '\\u0026')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
}

function normalizeTranslationStrings(parsed) {
  const source = parsed && typeof parsed === 'object' && !Array.isArray(parsed)
    ? (parsed.strings && typeof parsed.strings === 'object' && !Array.isArray(parsed.strings) ? parsed.strings : parsed)
    : {};
  const sanitized = {};
  Object.keys(source).forEach((key) => {
    if (key.indexOf('nav.') === 0) return;
    sanitized[key] = source[key];
  });
  return sanitized;
}

async function loadHomeSsrContent(env, origin, navLabelsPromise) {
  try {
    const [navLabels, leadData, latestPosts, popularPosts, picksPosts, koreaPosts, aprPosts, wosmPosts, peoplePosts, footerAnalytics] = await Promise.all([
      navLabelsPromise,
      loadHomeLead(env, origin).catch(() => ({ post: null })),
      loadLatestPosts(env, origin, 4).catch(() => []),
      // 추천·인기는 /api/home 과 같은 기준을 써야 초기 페인트 후 목록이 바뀌지 않는다.
      loadSsrRails(env, origin).then((r) => r.popular).catch(() => []),
      loadSsrRails(env, origin).then((r) => r.picks).catch(() => []),
      loadPostList(env, origin, { category: 'korea', limit: 4 }).catch(() => []),
      loadPostList(env, origin, { category: 'apr', limit: 4 }).catch(() => []),
      loadPostList(env, origin, { category: 'wosm', limit: 4 }).catch(() => []),
      loadPostList(env, origin, { category: 'people', limit: 4 }).catch(() => []),
      loadFooterAnalytics(env).catch(() => ({
        total_unique: 0,
        total_pageviews: 0,
        today_unique: 0,
      })),
    ]);

    const latestRail = latestPosts.slice(0, 3);
    const popularRail = (popularPosts.length ? popularPosts : latestPosts).slice(0, 4);
    const picksRail = picksPosts.slice(0, 4);
    const leadPost = leadData.post || picksPosts[0] || latestPosts[0] || null;

    // 메인 스토리 이미지는 홈 LCP candidate. 실제 이미지(placeholder 아님)일 때만 preload 후보로 노출.
    // HTML 파싱 후 <img>에 도달해야 비로소 요청이 발생하던 것을 head에서 미리 hint해 200~500ms 단축.
    const heroPreloadUrl = leadPost && leadPost.image_url && !leadPost.image_is_placeholder
      ? String(leadPost.image_url)
      : '';

    const payload = {
      lead: renderHomeLeadStory(leadPost, navLabels),
      latest: renderMiniList(latestRail, navLabels, {}),
      popular: renderMiniList(popularRail, navLabels, {}),
      picks: renderMiniList(picksRail, navLabels, {}),
      korea: renderMiniList(koreaPosts.slice(0, 4), navLabels, { hideCategoryChip: true }),
      apr: renderMiniList(aprPosts.slice(0, 4), navLabels, { hideCategoryChip: true }),
      wosm: renderMiniList(wosmPosts.slice(0, 4), navLabels, { hideCategoryChip: true }),
      people: renderMiniList(peoplePosts.slice(0, 4), navLabels, { hideCategoryChip: true }),
      heroPreloadUrl,
      footer: {
        totalVisitors: formatCount(footerAnalytics.total_unique),
        totalViews: formatCount(footerAnalytics.total_pageviews),
        todayVisitors: formatCount(footerAnalytics.today_unique),
      },
    };
    if (hasMeaningfulHomeSsrPayload(payload)) return payload;
    const emergencyPosts = latestPosts.length ? latestPosts : await loadLatestPosts(env, origin, 4).catch(() => []);
    return buildEmergencyHomeSsrPayload(emergencyPosts, navLabels);
  } catch (err) {
    console.error('[home-ssr] failed to build fallback:', err);
    return buildEmergencyHomeSsrPayload([], {});
  }
}

function applyHomeSsrContent(response, payload) {
  if (!payload) return response;
  const sections = {
    '#home-lead-story': payload.lead,
    '#latest-list': payload.latest,
    '#popular-list': payload.popular,
    '#popular-list-mobile': payload.popular,
    '#picks-list': payload.picks,
    '#picks-list-mobile': payload.picks,
    '#col-korea': payload.korea,
    '#col-apr': payload.apr,
    '#col-wosm': payload.wosm,
    '#col-people': payload.people,
  };
  const footerStats = payload.footer || {};
  let rewriter = new HTMLRewriter();
  Object.entries(sections).forEach(([selector, html]) => {
    rewriter = rewriter.on(selector, {
      element(element) {
        element.setInnerContent(html || '<div class="mini-empty">게시글이 없습니다</div>', { html: true });
      }
    });
  });
  rewriter = rewriter
    .on('#home-total-visitors', {
      element(element) {
        element.setInnerContent(String(footerStats.totalVisitors || '0'));
      }
    })
    .on('#home-total-views', {
      element(element) {
        element.setInnerContent(String(footerStats.totalViews || '0'));
      }
    })
    .on('#home-today-visitors', {
      element(element) {
        element.setInnerContent(String(footerStats.todayVisitors || '0'));
      }
    });
  // 메인 스토리 hero를 head에 preload — placeholder/로고 fallback일 때는 추가 안 함 (필요한 트래픽만).
  if (payload.heroPreloadUrl) {
    const safeHero = escapeHtml(payload.heroPreloadUrl);
    rewriter = rewriter.on('head', {
      element(element) {
        element.append(
          `<link rel="preload" as="image" href="${safeHero}" fetchpriority="high">`,
          { html: true }
        );
      }
    });
  }
  return rewriter.transform(response);
}

async function loadFooterAnalytics(env) {
  const [todayUnique, totalUnique, totalViews] = await Promise.all([
    scalar(env, `SELECT COUNT(DISTINCT viewer_key) AS count
                   FROM site_visits
                  WHERE path NOT LIKE '/api/%'
                    AND path NOT IN ('/admin', '/admin.html')
                    AND datetime(visited_at, '+9 hours') >= datetime(date('now', '+9 hours'))`),
    scalar(env, `SELECT COUNT(DISTINCT viewer_key) AS count
                   FROM site_visits
                  WHERE path NOT LIKE '/api/%'
                    AND path NOT IN ('/admin', '/admin.html')`),
    scalar(env, `SELECT COUNT(*) AS count
                   FROM site_visits
                  WHERE path NOT LIKE '/api/%'
                    AND path NOT IN ('/admin', '/admin.html')`),
  ]);
  return {
    today_unique: todayUnique,
    total_unique: totalUnique,
    total_pageviews: totalViews,
  };
}

async function loadHomeLead(env, origin) {
  const row = await env.DB.prepare(`SELECT value FROM settings WHERE key = 'home_lead_post'`).first();
  const postId = row ? parseInt(row.value, 10) : 0;
  if (!postId) return { post: null };
  const post = await env.DB.prepare(
    `SELECT id, category, title, subtitle, content, image_url, created_at, publish_at, tag, author
       FROM posts
      WHERE id = ? AND published = 1`
  ).bind(postId).first();
  return { post: post ? serializePostImage(post, origin) : null };
}

async function loadLatestPosts(env, origin, limit) {
  const safeLimit = Math.max(1, Math.min(10, parseInt(limit || 4, 10)));
  const { results } = await env.DB.prepare(
    `SELECT id, category, title, subtitle, content, image_url, created_at, publish_at, tag, author
       FROM posts
      WHERE published = 1
      ORDER BY ${PUBLIC_DATE_EXPR} DESC, id DESC
      LIMIT ?`
  ).bind(safeLimit).all();
  return (results || []).map((post) => serializePostImage(post, origin));
}

/**
 * SSR 폴백용 추천·인기 레일. functions/_shared/home-rails.js 의 기준을 그대로 쓴다.
 * 요청 안에서 한 번만 계산해 두 섹션이 나눠 쓴다.
 */
function loadSsrRails(env, origin) {
  if (!env.__ssrRailsPromise) {
    env.__ssrRailsPromise = (async () => {
      const { pickIds, popularIds } = await selectHomeRailIds(env, 4);
      const ids = [...new Set([...pickIds, ...popularIds])];
      const cards = await hydrateByIds(env, ids, `id, category, title, subtitle, content, image_url, created_at, publish_at, tag, author`, (row) => serializePostImage(row, origin));
      const byId = new Map(cards.map((c) => [c.id, c]));
      return {
        picks: pickIds.map((id) => byId.get(id)).filter(Boolean),
        popular: popularIds.map((id) => byId.get(id)).filter(Boolean),
      };
    })();
  }
  return env.__ssrRailsPromise;
}
async function loadPostList(env, origin, opts = {}) {
  const conditions = ['published = 1'];
  const bindings = [];
  if (opts.category) {
    conditions.push('category = ?');
    bindings.push(opts.category);
  }
  if (opts.featured) conditions.push('featured = 1');
  const safeLimit = Math.max(1, Math.min(10, parseInt(opts.limit || 4, 10)));
  const { results } = await env.DB.prepare(
    `SELECT id, category, title, subtitle, content, image_url, created_at, publish_at, tag, author
       FROM posts
      WHERE ${conditions.join(' AND ')}
      ORDER BY ${PUBLIC_DATE_EXPR} DESC, id DESC
      LIMIT ?`
  ).bind(...bindings, safeLimit).all();
  return (results || []).map((post) => serializePostImage(post, origin));
}

function renderHomeLeadStory(post, navLabels) {
  if (!post) return '<div class="mini-empty">대표 기사를 준비 중입니다</div>';
  const excerpt = escapeHtml(getPostExcerpt(post, 220));
  const subtitle = escapeHtml(String(post.subtitle || '').trim());
  const categoryLabel = escapeHtml(getCategoryLabel(post.category, navLabels));
  const tagClass = escapeHtml(getCategoryTagClass(post.category));
  const tags = getSortedPostTags(post).map((tag) => `<span class="post-kicker tag-${escapeHtml(post.category || 'korea')}-kicker">${escapeHtml(tag)}</span>`).join('');
  const image = post.image_url
    ? `<a class="home-lead-thumb-link${post.image_is_placeholder ? ' is-placeholder' : ''}" href="/post/${post.id}"><img class="home-lead-thumb${post.image_is_placeholder ? ' is-placeholder' : ''}" src="${escapeHtml(post.image_url)}" alt="${escapeHtml(post.title)}" loading="eager" fetchpriority="high"></a>`
    : '';
  return (
    `<article class="home-lead-card">` +
      image +
      `<div class="home-lead-body">` +
        `<div class="home-lead-copy">` +
          `<div class="home-lead-labels">` +
            `<span class="category-tag ${tagClass}">${categoryLabel}</span>` +
            tags +
            `<span class="home-lead-kicker">메인 스토리</span>` +
          `</div>` +
          `<h3><a class="home-lead-link" href="/post/${post.id}">${escapeHtml(post.title)}</a></h3>` +
          (subtitle ? `<p class="home-lead-subtitle">${subtitle}</p>` : '') +
          (excerpt ? `<p class="home-lead-excerpt">${excerpt}</p>` : '') +
        `</div>` +
        `<div class="home-lead-footer">` +
          `<div class="home-lead-meta">${escapeHtml(formatPostDate(post))}${post.author ? ` · ${escapeHtml(post.author)}` : ''}</div>` +
          `<div class="home-lead-actions"><a class="home-subscribe-btn" href="/post/${post.id}">기사 읽기</a></div>` +
        `</div>` +
      `</div>` +
    `</article>`
  );
}

function renderMiniList(posts, navLabels, options) {
  const opts = options || {};
  if (!Array.isArray(posts) || !posts.length) {
    return '<div class="mini-empty">게시글이 없습니다</div>';
  }
  return posts.map((post) => renderMiniItem(post, navLabels, opts)).join('');
}

function hasMeaningfulHomeSsrPayload(payload) {
  if (!payload || typeof payload !== 'object') return false;
  return ['lead', 'latest', 'popular', 'picks', 'korea', 'apr', 'wosm', 'people'].some((key) => {
    return String(payload[key] || '').indexOf('/post/') >= 0;
  });
}

function buildEmergencyHomeSsrPayload(posts, navLabels) {
  const safePosts = Array.isArray(posts) ? posts.slice(0, 4) : [];
  const latestHtml = renderMiniList(safePosts, navLabels, {});
  const emptyHtml = '<div class="mini-empty">게시글을 준비 중입니다</div>';
  return {
    lead: renderHomeLeadStory(safePosts[0] || null, navLabels),
    latest: latestHtml,
    popular: emptyHtml,
    picks: emptyHtml,
    korea: emptyHtml,
    apr: emptyHtml,
    wosm: emptyHtml,
    people: emptyHtml,
    footer: {
      totalVisitors: '0',
      totalViews: '0',
      todayVisitors: '0',
    },
  };
}

function formatCount(value) {
  const number = Number(value || 0);
  if (!Number.isFinite(number)) return '0';
  return new Intl.NumberFormat('ko-KR').format(number);
}

async function scalar(env, sql) {
  const row = await env.DB.prepare(sql).first();
  if (!row) return 0;
  const value = row.count ?? row.total ?? row.n ?? Object.values(row)[0] ?? 0;
  const num = Number(value);
  return Number.isFinite(num) ? num : 0;
}

function renderMiniItem(post, navLabels, options) {
  const opts = options || {};
  const thumb = post.image_url
    ? `<img class="mini-thumb${post.image_is_placeholder ? ' is-placeholder' : ''}" src="${escapeHtml(post.image_url)}" loading="lazy" alt="${escapeHtml(post.title || '')}">`
    : '';
  return (
    `<article class="mini-item">` +
      `<div class="mini-item-row">` +
        `<div class="mini-item-text">` +
          `<div class="mini-item-labels">${buildMiniLabels(post, navLabels, opts)}</div>` +
          `<h4><a class="mini-item-link" href="/post/${post.id}">${escapeHtml(post.title)}</a></h4>` +
          `<div class="mini-meta">${escapeHtml(formatPostDate(post))}</div>` +
        `</div>` +
        thumb +
      `</div>` +
    `</article>`
  );
}

function buildMiniLabels(post, navLabels, options) {
  const opts = options || {};
  const labels = [];
  if (!opts.hideCategoryChip) {
    labels.push(`<span class="category-tag ${escapeHtml(getCategoryTagClass(post.category))}">${escapeHtml(getCategoryLabel(post.category, navLabels))}</span>`);
  }
  getSortedPostTags(post).forEach((tag) => {
    labels.push(`<span class="post-kicker tag-${escapeHtml(post.category || 'korea')}-kicker">${escapeHtml(tag)}</span>`);
  });
  return labels.join('');
}

function getCategoryLabel(category, navLabels) {
  const keyMap = {
    korea: 'korea',
    apr: 'apr',
    wosm: 'wosm',
    people: 'people',
  };
  const key = keyMap[String(category || '').trim()] || 'korea';
  const label = String(getNavLabel(navLabels, key, 'ko') || '').trim();
  if (label) {
    if (key === 'apr') return label.toUpperCase();
    if (key === 'wosm') return label.toUpperCase();
    if (key === 'korea') return label.charAt(0).toUpperCase() + label.slice(1);
    return label;
  }
  return {
    korea: 'Korea',
    apr: 'APR',
    wosm: 'WOSM',
    people: '스카우트 인물',
  }[key] || 'Korea';
}

function getCategoryTagClass(category) {
  const safe = String(category || 'korea').trim();
  return {
    korea: 'tag-korea',
    apr: 'tag-apr',
    wosm: 'tag-wosm',
    people: 'tag-people',
  }[safe] || 'tag-korea';
}

function getSortedPostTags(post) {
  return String((post && post.tag) || '')
    .split(',')
    .map((tag) => tag.trim())
    .filter(Boolean)
    .sort((a, b) => a.localeCompare(b, 'ko'));
}

function formatPostDate(post) {
  const value = String(post && (post.publish_at || post.created_at) || '').trim();
  if (!value) return '';
  const normalized = value.replace(' ', 'T');
  const withZone = /Z$|[+-]\d{2}:\d{2}$/.test(normalized) ? normalized : `${normalized}+00:00`;
  const date = new Date(withZone);
  if (Number.isNaN(date.getTime())) return value.slice(0, 10);
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Seoul',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(date).reduce((acc, part) => {
    acc[part.type] = part.value;
    return acc;
  }, {});
  return `${parts.year}.${parts.month}.${parts.day}`;
}
