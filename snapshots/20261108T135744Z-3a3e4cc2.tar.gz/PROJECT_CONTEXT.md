# BP미디어 공개 홈페이지 작업 상태

## 2026-10-29 — Rust 서버 전환 후속과 배포 지시

- 사용자 지시: "작업을 마치면 배포할것". 전체 Rust 전환과 필요한 검증을 마친 뒤 운영 배포하는 범위에 대한 명시 지시다. 프로젝트의 커밋·푸시 승인 경계는 별도로 확인한다. 아직 배포 조건 미충족.
- 홈 추천·인기 선정, 기사 공감 수, 중복 방지 조회수 기록, 수동/자동 관련 기사·특집 기사 DB 조회를 Rust로 이전했다. 관련 기사 점수화·인증·입력 정규화·나머지 서버는 여전히 JS다.
- 기존 구현과 비교하는 합성 DB 계약 테스트 31개 통과. 권한·공감 중복·12시간 조회 중복·동시 삽입·관련 비공개 기사 제외·추천/인기 중복 제외와 날짜별 가중치를 확인했다. 전체 Functions 실제 workerd+D1 및 Chrome 홈→목록→상세 검사를 다시 통과했다.
- 로컬 workerd 종료 시 간헐적 broken pipe가 관찰됐다. 브라우저가 설정·통계 요청을 처리 중 닫힐 때의 로그라는 가설을 조사 중이다. 무관한 운영 장애로 단정하지 않으며 테스트 종료 대기 보완 후 재검증 중이다. 상세 `work/rust-migration/failures.md`.
- 운영 P0 재조회 0건, 운영 쓰기·커밋·푸시·배포 없음. 기존 사용자의 미커밋 worktree는 유지했다. 남은 전환과 실제 계정·성능·복구/배포 검증은 `server-rust/README.md` 참조.

## 2026-10-29 — Rust 서버 전환 후속 (진행 중, 미배포)

- 별도 `bpmedia-rust-server` worktree에서 기사 목록·검색·정렬·태그·특집·인기, 기사 상세 원본 조회, 홈 최신/분야별 기사와 공개 기사 통계 DB 처리를 Rust로 이전했다. 기사 인증·조회수·공감·관련 기사·이미지 후처리 및 나머지 홈 로더는 기존 JS다.
- 시작 시 `origin/main`과 기준 HEAD `835a326a` 일치, 원본 `bpmedia-material3` 미커밋 변경 보존, 운영 고심각도 open/monitoring 이슈 0건. 운영 DB 읽기 1회·쓰기 0건.
- 원본 `835a326a` 테스트 fixture와 34개 기사 목록 조건, 기사 상세 공개/비공개·조회수·관련 기사, 태그/인기/특집, 홈 응답·부분 장애, 통계의 비교 통과. Rust/기존 JS 계약 테스트 27개, 실제 workerd+D1 통합 통과. 합성 기사 101건·동시 요청 12건 및 Chrome 390/1440px 홈→목록→상세 확인. 외부 요청을 막고 합성 DB 사용.
- 내부 Wasm 호출용 `/__internal/`을 공통 미들웨어에서 404 차단하고 권한 정보 위조 및 직접 접근 회귀 확인. 소스·운영 데이터·인증 코어의 기존 변경을 덮지 않았다. 사용자 화면 변경 없음.
- 로컬 실행 중 fixture 시간 불일치, 없는 Miniflare 메서드, 합성 DB의 누락된 도감 테이블을 수정해 재검증. 세부 실행 기록 `work/rust-migration/failures.md`. 운영 장애의 증거가 아니다.
- 전체 서버 Rust 전환·전체 기능 및 실제 계정 검수·운영 성능·배포/복구 검증은 미완료. 상세 상태와 다음 순서는 `server-rust/README.md`. 커밋·푸시·배포 없음.

## 2026-10-29 — Rust 서버 1차 전환 (별도 worktree, 미배포)

- 사용자 선택: 기존 기능·화면을 유지하며 서버를 Rust로 전환. 최신 origin/main을 별도 worktree에서 시작하고 원래 로컬 미커밋 변경 보존. 작업 위치는 `../bpmedia-rust-server`, 브랜치는 `feat/rust-server-migration`, 기준 HEAD는 `835a326a`. 원래 `bpmedia-material3`의 소스는 수정하지 않았다.
- 용어집 3개 경로/5개 핸들러의 DB·분류·정렬·검색·JSON/텍스트 응답을 Rust/Wasm으로 이전. 인증·메뉴 권한·쓰기 제한·CORS/CSRF·JS 입력 정규화는 기존 구현 재사용. auth.js, DB 스키마, 운영 데이터, R2, 공개 화면 변경 없음.
- 기사 목록·상세·공감·조회수·관련 기사 조회·점수화·정렬, 홈 추천·히어로·설정·통계 조회, 방문 통계 집계·방문 및 체류 기록, 기사 내보내기·사이트맵·RSS·도감 목록·상세 조회 및 생성·수정·삭제의 본문·관계·검색 색인 D1 원자적 저장(오류 주입과 동시 수정 검증), 예약 발행, 홈 배너·기여자·히어로와 메인 기사 설정의 원자적 저장, 용어집·일정·도감 SSR, 회원국·참고 사이트·게시판 문구·사이트 메타·KMS·개인정보 처리방침 설정의 원자적 저장·조회와 게시판·캘린더·평가 기준·작성자·AI 안내·티커·배너·번역·메뉴명·태그 설정, 일정 CRUD와 기사 생성 INSERT, 수정 UPDATE 및 삭제 DELETE도 Rust로 이전. 인증·입력·이미지 처리와 생성 행 조회·이력·캐시 무효화는 기존 JS 유지. 선택값 생략 시 기존 D1 오류도 보존했다.
- 사용자 지시: 전체 작업을 마치면 운영 배포. 현재 전체 전환은 미완료이며 커밋·푸시 승인 경계는 따로 확인해야 한다.
- Rust 1.99.1 minimal toolchain/wasm32 target와 worker-build 0.8.7을 공식 경로로 설치. 셸 프로필은 수정하지 않았고 빌드 스크립트의 PATH에서 사용. Cargo.lock 고정, 소스/빌드는 public 밖, 추가 내부 경로 차단.
- 도감 검색 기록의 D1 쓰기를 Rust로 이전하고 백그라운드 작업을 waitUntil로 유지했다. 합성 검색어·필터·결과 수 기록을 격리 D1에서 검증했다.
- 도감 검색의 용어집 별칭 조회와 FTS 후보 검색을 Rust로 이전했다. 한글·영문 별칭, 공개 필터, 국가·분류·태그 조건과 후보 500건 상한을 격리 데이터로 검증했다. 최종 공개 필터·정렬·목록·총 수와 패싯 집계도 Rust로 이전했으며, 일부 패싯 실패 시 기존 부분 결과를 유지한다.
- 예약 발행 시 저장 직전 발행 조건을 재검사해 재예약된 기사 조기 공개를 방지하고 실제 발행된 기사만 반환한다. 자동 발행과 실제 순서 변경 시 편집 기준 시각을 증가시키며 동시 발행·오래된 편집·순서 초기화 검사를 통과했다.
- 기사 편집의 expected_updated_at을 D1 트랜잭션에서 비교하고 수정 시각을 밀리초 단위로 단조 증가시킨다. 동일 버전 동시 편집은 1건 저장·1건 409, 상태 변경 후 오래된 편집 거부 및 이력 1건을 격리 D1에서 검증했다. 기준 시각이 없는 구형 요청은 기존처럼 잠금이 없다.
- 기사 수정·상태 변경과 수정 전후 이력을 각각 단일 D1 트랜잭션으로 결합했다. 이력 생성·완성 단계의 오류 주입과 실제 격리 D1 스냅샷을 검증했다. 기준 시각을 가진 편집의 동시 수정 검사를 저장 트랜잭션에서 수행하도록 보강했다.
- 기사 생성과 생성 이력 스냅샷을 단일 D1 트랜잭션으로 결합했다. 이력 저장 실패 시 기사도 롤백되고 실제 스키마의 모든 컬럼이 이력에 보존되는 것을 격리 환경에서 확인했다.
- 기사 변경 이력 저장의 D1 처리를 Rust로 이전하고 기존 스냅샷과 실패 처리 동등성을 확인했다. 기사 수정·상태 변경 이력도 단일 트랜잭션으로 결합했다.
- 기사 조회 기록 삽입과 조회수 증가를 단일 D1 트랜잭션으로 묶어 증가 실패 시 기록도 롤백한다. 중복·동시 요청과 오류 주입을 격리 D1에서 확인했다.
- 기사 공감의 공개 여부 확인과 중복 방지 저장을 Rust로 이전하고, 저장 직전 비공개로 전환된 기사에 새 공감이 남지 않도록 보강했다. 동일 방문자 동시 요청과 비공개 전환을 격리 환경에서 검증했다.
- 기사 순서 저장·초기화, 수정 이력과 공개 대표 이미지의 D1 조회를 Rust로 이전했다. 관리자 인증·비공개 이미지 차단·정렬 오류 롤백을 격리 환경에서 확인했다.
- 도감 발행처·태그 자동완성 조회를 Rust로 이전하고 검색어·빈도 순위·제한 수를 기존 구현 및 격리 D1과 비교했다.
- 도감 일괄 찾아 바꾸기의 미리보기·실제 치환을 Rust로 이전하고 테이블·컬럼 허용 목록을 검증했다. 행사명과 자료 내 행사명의 동시 변경을 D1 단일 트랜잭션으로 묶고 오류 롤백을 확인했다. 검색 색인은 별도 후처리이며 실패 건수를 관리자에 표시한다.
- 도감 검색 색인 갱신 시 본문·태그·국가·분류 스냅샷을 D1 트랜잭션 안에서 재확인한다. 준비 중 변경 시 이전 색인 덮어쓰기를 거부하고 후속 재시도로 최신 내용을 반영하는 합성 검사를 통과했다. 일반 색인 갱신은 별도 실행이지만 자료별 일괄 수정은 이제 색인을 같은 트랜잭션에 포함한다.
- 도감 검색 색인의 기존 행 삭제·신규 삽입을 Rust 단일 D1 트랜잭션으로 처리해 삽입 실패 시 기존 색인을 보존한다. 일괄 수정의 색인 실패 ID를 응답하고 관리자 알림에 실패 건수를 표시한다. 관리자 화면 실제 조작 검증은 남아 있다.
- 도감 일괄 수정의 자료별 본문·행사 사용 수·태그·국가·검색 색인을 Rust 단일 D1 트랜잭션으로 저장한다. 색인 실패 롤백, 동시 본문·행사·분류·태그 변경 감지, 30개 태그와 8개 국가를 격리 D1에서 검증했다.
- 관리자 도감 댓글의 상태별 집계·목록·승인·반려·삭제를 Rust로 이전했다. 권한·OTP와 비밀번호 정보 비노출을 유지하고 동시 삭제된 댓글의 재승인을 방지했다.
- 도감 승인 댓글 조회·작성·작성자 삭제의 D1 처리를 Rust로 이전했다. 승인 대기·비밀번호 검증·개인정보 비노출·DB 실패 및 내부 경로 차단을 격리 환경에서 확인했다.
- 도감 공감 토글·집계와 조회 기록·카운트 조회를 Rust로 이전하고 조회 기록과 증가를 D1 단일 트랜잭션으로 처리했다. 비공개 자료 공감 차단, 봇 제외, 12시간 중복 방지, 동시 요청과 오류 롤백을 격리 환경에서 검증했다.
- 행사 CSV 가져오기·내보내기의 행사 읽기·저장 경로를 Rust로 연결했다. 중복 행 갱신, 날짜·분류 매칭, 행별 오류와 후속 행 처리, CSV 출력 및 권한을 격리 데이터로 비교했다. CSV 파싱과 중복 결정은 기존 JS 유지.
- 도감 행사 목록·상세·실시간 연결 자료 수·생성·수정·삭제와 분류/보관 일괄 수정의 D1 처리를 Rust로 이전했다. 날짜 표시와 행사 삭제 시 자료 보존·연결 해제, 저장 실패를 격리 데이터로 검증했다.
- 도감 행사 분류 목록·사용 수·생성·수정·삭제를 Rust로 이전했다. 삭제 시 행사를 보존하고 분류 연결만 해제하며, 기존 오류 메시지·관리자 접근 제한을 합성 및 격리 D1에서 확인했다.
- 도감 분류 목록·생성·수정·삭제를 Rust로 이전하고 사용 중 분류의 보관·삭제 판단을 단일 D1 트랜잭션으로 묶었다. 동시 연결·단계 실패·중복 slug와 관리자 권한을 격리 데이터로 확인했다.
- 관리자 운영 이력의 운영·장애·설정·기사 4개 출처 조회를 Rust로 이전했다. 출처별 부분 실패와 기존 통합·중복 제거, 관리자 권한과 OTP를 합성 및 격리 실행 환경에서 검증했다.
- 홈 장애 보고의 기존 이슈 중복 조회·생성·갱신과 관리자 목록 검색·정렬·상태 변경을 Rust로 이전했다. 관리자 권한·OTP·수동 생성/삭제 금지와 DB 실패를 격리 환경에서 확인했다. 기존 동작 비교와 격리 workerd의 동일 보고 2회 누적을 확인했다. 동시 요청의 Miniflare 직접 호출에서 본문 소비 오류가 간헐적으로 관찰되어 BP미디어와 D1이 없는 최소 Worker에서도 동일 현상을 재현했다. 원인은 미확정이며 격리 HTTP 동시 요청과 최소 Worker HTTP 240건은 통과했다.
- 홈 번역·티커 정상 설정 정규화를 Rust로 이전하고 잘못된 설정은 기존 JS 오류·fallback을 유지. 추천·인기 레일 캐시를 요청 범위로 제한해 재사용 환경에서 최신 조회수가 반영되도록 수정했다.
- 검증: 실제 Wasm을 통한 Node 계약 166개 통과, 원래 용어집과 응답/저장 결과 비교, 전체 Pages 번들 + 실제 workerd/격리 D1 통합 1개 통과. 권한 401/403·CSRF 403·CORS·UTF-16 입력·BOM 검색·CAS 409·단조 증가 timestamp·삭제·기존 version API·내부 경로 404 확인. Rust 단위 1개·Clippy 경고 0·fmt·노출 감사 통과.
- 실패/해결: full strip으로 wasm-bindgen externref 테이블이 제거돼 빌드 실패 → strip=debuginfo로 해결. 테스트 D1 생성자명/fixture 문법, ECMAScript BOM trim, Miniflare 모듈 순서를 교정하고 재검증. 안전한 실행 기록은 work/rust-migration/failures.md, 공유 메모리는 미수정.
- 배포 호출부: production·Dreampath·rollback workflow에 Rust 빌드 연결. Dreampath 앱/서버의 기능 이전은 제외하되 전체 Functions의 공용 빌드 의존성은 반영. workflow 실제 실행·롤백은 미검증.
- 운영: 시작 시 P0 고심각도 0건, read-only SELECT 1회/운영 쓰기 0. 커밋·푸시·배포·버전 bump 미수행. 전체 서버 Rust화·브라우저/실계정 검수·성능 비교는 미완료. 다음 순서는 나머지 관리 쓰기/설정 → HTML/SEO이며 완료 조건과 남은 범위는 server-rust/README.md에 정리.

공개 Site 정본은 `bpmedia-material3` worktree의 `main`, 배포 정적 루트는 `public/`이다. 이 Rust 전환 worktree는 위 기준에서 분기한 미배포 작업 사본이다. 연결된 `gilwell-media` worktree는 Mac Writer 작업용이다. 기술 구성과 실행 환경은 `README.md`, 승인·타겟별 규칙은 `AGENTS.md`와 `rules/`를 따른다.

## 2026-10-04 — 홈 스카우트 활동 안내 디자인

- `public/index.html`: 공통 `home-section-title`과 `home-rail-card`로 제목과 본문을 구성했다. 설명·네 주제 링크는 유지했다.
- `public/css/m3-site.css`, `public/css/topics.css`: 기존 M3 칩 규칙을 재사용하고 설명 크기·여백을 정리했다. 주제 상세 페이지 링크 스타일은 보존했다.
- 검증: 설치된 Chrome으로 1440/390/360/320px에서 가로 넘침 없음, 네 링크 44px 높이와 밑줄 제거 확인, 키보드 포커스 3px 확인. 데스크톱·모바일 캡처 시각 확인. APCA 본문 97.6, 칩 85.3, 포커스 84.4. `git diff --check` 통과. 원격 P0 조회 0건.
- 범위/위험: 공개 정적 HTML·CSS만 변경. 운영 데이터·인증·API 변경 없음. 로컬 검증이며 운영 반영은 승인 대기다.
- 검증 환경 참고: 기본 Playwright Chromium 실행 파일이 없어 최초 실행 실패. 추가 설치 없이 `channel: 'chrome'`으로 실제 브라우저 검증 완료. 정적 서버에는 API가 없어 홈 데이터 오류 알림이 표시되며 운영 오류의 증거가 아니다.
- 다음 작업: 사용자 커밋·배포 승인 후 `rules/02-versioning.md`, `rules/03-deploy.md`를 읽고 버전·changelog·자산 버전 동기화 및 release preflight를 수행한 다음 표준 배포와 라이브 화면 검증을 진행한다.

## 2026-10-08 — 단계별 아이콘 버튼과 사이트맵 검수

- 사용자 승인: 이번 요청의 내부 검수 2회 이후 커밋·푸시·production 배포 자동 진행.
- 기존 미배포 홈 스타일 변경을 보존·활용하며 네 링크에 발자국/나침반/산/악수 SVG를 추가했다. 공개 링크 의미와 목적지를 유지했다.
- 사이트맵: 배포 전 apex·www 리다이렉트·Googlebot·Yeti GET에서 일반/뉴스 XML 정상. 보고된 HTML 응답은 재현되지 않았으며 정확한 오류 URL 확인 대기. 원인 해결을 단정하지 않는다.
- 응답 길이만 검사하던 기존 회귀 검사를 XML Content-Type·GET/HEAD·HTML 부재 확인으로 강화하고 표준 배포 후 검사에 두 XML 파싱을 추가했다.
- SQLite fixture의 special_feature 누락으로 사이트맵 오류가 숨겨지던 기존 테스트를 수정하고 공개 기사 포함/초안 제외를 확인했다.
- 검증/실패 근거: work/gpt-scout-buttons-20261008. 운영 데이터·인증 변경 없음. 잔여위험은 검색서비스가 기록한 과거 오류/실제 색인 상태 미확인.

- 내부 검수 1회: SQLite/주제 페이지 및 라이브 XML GET/HEAD 통과, Chrome 1440/390/360/320 캡처 확인. 320px 줄 배치 개선 필요 발견.
- 내부 검수 2회: 모바일 2열 정리 후 UI 회귀/주제 SQLite/XML 검사 모두 통과, 4폭 캡처 확인. APCA 라벨85.34·포커스84.41, 메타데이터·노출 경계·diff 검사 통과.
- 기존 2026-10-03 외장 암호화 D1/R2 백업 파일 readback SHA256을 검증 기록과 대조해 일치 확인. 이 요청은 데이터 모델/DB 변경 없음, 이전 커밋 및 이번 release snapshot으로 코드 롤백 가능.

## 2026-10-08 — 후속 균등 너비/가운데 정렬

- 기존 카드/아이콘/링크를 보존하고 홈 안내 링크를 4열 균등 Grid, 768px 이하 2열로 적용. 설명문 가운데 정렬.
- 6폭(1440/800/768/601/390/320) 회귀 검사에서 동등 너비, 우측 카드 끝 정렬, 행 수, 설명문 중앙, 높이/포커스/넘침 확인. 1차 검사 통과; 2차 캡처·메타데이터 검사 후 기존 승인으로 커밋/배포.
- P0 D1 최초7403는 과거 사례를 확인하고 read-only1회 재시도 성공(0건). 운영 쓰기0.

## 2026-10-08 — 용어집 현행화

- 회원국 현황 revision5의230개 조직 대조. 기존36개 조직 정비, 미등재194개 조직+기본 용어8개 추가. 총133→335개; 기존93개 항목 수정. ID·생성일·불어 및 기존 별칭 설명 보존.
- 미국은 공식 자료로 확인한 Scouting America 유지. 한국어 공식명이 미확정인54개 조직은 원문 유지, 신규 국가별 국문명은 안내 명칭임을 명시. NSO/연합/NSA/연계 단체 구분.
- 영문 오탈자·용어 의미 정비, 빈 설명 보완. 현행화 날짜 및 회원국 현황 링크 표시.
- 기존 bucket CHECK 가나다14개 제한 확인. storageBucket을 POST·PUT에 공용 적용, 공개 분류 보존. 인증·권한·스키마 변경 없음. KMS9.2.1/14 기록 후 D1 원본 스냅샷 동기화.
- 검수1: 명칭·분류·한도·중복·230개 조직 연결,133행 암호화 백업 인증·SQLite 복원. 검수2: 실제 CHECK 기반 SQL 재실행·동시 수정 보호·기존 번역/ID 보존 및 공용 저장 매핑 검사.
- 원격 반영: import RESET_DO2회 실패 후133행 보존 확인. bounded query 전환 중 CHECK 및 임시 실행기의 다중행 분리 오류 수정. 최종335개 모든 변경 필드·추가 항목 독립 원격 export/API 대조 완료. 공유 failures/gpt-2026-10-08-bpmedia-glossary-d1-reset.md에 기록.
- 백업: 외장 Project_Server_Backups/bpmedia/20261008-glossary-before.json.enc 및 KMS 암호화 전본; 키는 기기 로컬. 근거 work/gpt-glossary-20261008.
- 잔여위험: 사이트 회원국 현황 기준이며230개 단체의 공식 한국어 번역을 확정한 작업은 아니다. 관리자 실제 계정 저장은 수행하지 않았으며 저장 매핑 회귀/인증경계/실데이터 조회로 확인. 사용자 승인으로 커밋·푸시·표준production 배포.
- 최종 검수: live API335건·54국문 미확정, 실제 변경 필드 전체 일치. SQL/저장 매핑/메타데이터/공개 노출/diff 검증 통과.


## 2026-10-20 — Owner phone replacement (deployed)

public/about.html updates Jimmy Park's management contact to +82.10.2646.1635, tel:+821026461635 and JSON-LD +82-10-2646-1635. Other contacts and layout are unchanged. main matches origin/main; P0 query returned zero open/monitoring high/critical issues (first transient7403, retry succeeded). Mac Writer sibling about.html is synchronized to prevent reintroducing the retired number. Released with owner approval through rules/02-versioning.md and rules/03-deploy.md.

Owner approved commit/push/deploy. Public commit202191a5 pushed to main; standard production script deployed7d4d4881.gilwell-media.pages.dev, site00.194.01. Live About telephone and ContactPoint JSON-LD match the new number, retired number absent. Post-deploy version and sitemap checks passed. Writer sibling commitf9662d60 pushed to feat/bpmedia-mac-writer-v1. No phone-call test was performed; screenshot capture was unavailable, browser accessibility and independent HTTP were verified. Final public post audit:511 published posts,0 issues. Release snapshot20261019T165953Z-202191a5 saved successfully.

## 2026-10-23 — 주간 카드뉴스 자동 제작 (Admin)

- 승인된 세계스카우트 에셋/Wanted Sans/이사만루 1080×1350 디자인을 기존 카드뉴스 메뉴에 연결. 새 호만 주간 스튜디오, 기존 호는 기존 편집기 유지.
- 매주 월요일 09:00 KST의 직전 한 주, 이미지·본문을 확인한 기사로 편집 가능한 호 생성. 자동 게시 없음. 기사 선택·사진 위치 서버 저장, PNG/ZIP은 필요할 때 생성.
- D1 기존 테이블 사용, 인증·권한 재사용, revision 충돌 방지와 동일 기간 덮어쓰기 방지. 원문 posts 변경 없음.
- 구현/로컬 검증 완료. 기존 미커밋 Site 변경 보존. 사용자가 이번 변경만 커밋·푸시·운영 배포·cron 활성화를 명시 승인. 별도 깨끗한 배포용 복사본에서 이번 변경만 반영한다. 운영 로그인 확인은 배포 후 수행.
- 상세: docs/features/Weekly Card News.md. Admin 03.159.00 준비.

## 2026-10-23 — 주간 카드뉴스 디자인 스튜디오

- Admin03.160.00: 표지8종 무작위 선택(새 호에 한번 저장), 기사 배치4종, 문구·타이포·사진 높이/맞춤 조절. 기존 호의 디자인/사진과 posts를 보존한다.
- 기존 인증 프레임·PNG/ZIP·CAS를 재사용. latest renderId를 확인하여 빠른 입력 후에도 마지막 디자인을 내보낸다. 데이터/권한/서버 입력 경계 검사 통과, 실제 Chrome 8표지·4기사 레이아웃·최대값·긴 문구·저장재접속·사진·PNG/ZIP·모바일 검사 통과.
- 자동제작 cron은 기존 월요일00:00 KST를 유지. 10월26일 첫 실행을00:05에 읽기 전용으로 확인하는 일회성 Codex heartbeat(bp)를 별도로 등록했다. 첫 실행 자체는 아직 미래다.
- 기존 dirty checkout은 보존하며 깨끗한 weekly-release 복사본에서 카드뉴스 범위만 커밋·배포한다. 공유 패키지 변경을 포함하므로 scheduled Worker도 같은 helper로 재배포한다.


## 2026-10-27 — KMS 운영 기준 최신화

- 타겟 KMS. 운영 커밋4699dab1에서 분리한 작업 사본으로 진행하고 원래 공유 checkout의 미완료 Site 변경을 보존했다.
- 2026-10-24 카드뉴스 수동 전용 결정, 표지/기사 편집·권한·저장 충돌·PNG 검수, 용어집 검색 범위 복구, 설정 쓰기 권한을 KMS에 반영했다. 기존 자동 추천 승인 기준과 구형 수동 안내의 충돌 및 규칙/배포 경로도 정리했다.
- D1 revision4→6. 변경 전 본문은 settings_history에 보관하고 조건부 갱신·운영 로그·전체 readback을 확인했다. 원본에서 Markdown/fallback을 공식 스크립트로 동기화했다.
- KMS API 가이드의 로그인·세션·revision 예시를 정정하고 카드뉴스 API8개를 추가했다. 기능 동작·인증 코어·기사/카드 데이터·예약은 변경하지 않았다.
- 검증: SQL fixture 정상·stale·재실행, 설정 쓰기 권한4건, 카드뉴스 예약 비활성 검사, JS 문법·스냅샷 일치. 1440/390px 로컬 KMS 렌더·API8개·표시일·가로 넘침 없음·pageerror0 확인. Admin03.160.04 배포 완료.
- 후속 확인: KMS5.2의 과거 티커 버튼 제거 기록과5.9의 직접 정지 접근성 기준은 현재 조작 방식 검토가 필요하다. 이번 작업에서 Site 기능이나 기준을 임의 변경하지 않았다.
- 다음 시작: AGENTS.md→rules/README.md→rules/30-kms.md, PROJECT_CONTEXT.md를 읽고 git status --short, node scripts/sync_kms_snapshot.mjs --check, ./scripts/verify_release_metadata.sh 실행.

- 최종 릴리스: af750de를 origin/main에 push, Pages7f91f21a-f129-4b58-b0e2-73663a242512 배포 성공. live ADMIN_VERSION03.160.04·KMS revision6·전체 원문·JS byte 일치·changelog1건 확인. 표준 배포 exit0, 공개 기사536건/오류0건, snapshot20261027T083931Z-af750de 저장. 카드뉴스 Worker 예약0건 재확인. 후속 기록 커밋은 문서만 변경하며 배포 코드/자산은 바꾸지 않는다.

## 2026-11-01 — 10-22 안정성·SEO·AEO 수정을 Rust 기준으로 이식 (Site 00.195.03, 배포 완료)

- 기준 origin/main 6bc70670, worktree `bpmedia-stability-port`(브랜치 fix/site-stability-seo-port). 원래 checkout의 미커밋 10-22 변경은 보존(리셋·stash 없음)했고 이 브랜치가 그 대체본이다.
- sitemap·뉴스 sitemap·용어집 원문: DB/Rust 실패 시 기사 없는 200 대신 503 + no-store + Retry-After 300. sitemap의 죽은 JS 대체 경로 삭제. 용어집 "업데이트" 날짜는 실제 저장 시각(KST), 모르면 생략.
- `/post/:id.md`: 공개 작성자명, KST 날짜·postLastmod, 중첩 목록 보존, href 조각이 섞이던 출처 재추출 제거(Rust+JS 기준 동시). llms.txt 제목 대괄호 이스케이프, 편집 정책은 원문 링크로. NDJSON HEAD 추가, 오류 no-store.
- 기사 HTML/API: 공감·관련·수동 관련·특집 쿼리 실패는 해당 위젯만 비우고 기사 유지. 유니코드 범위 밖 숫자 엔티티 보호(서버·브라우저), 중첩 목록을 JSON-LD·설명·발췌에 포함. 모바일 당겨서 새로고침을 대화상자·입력·멀티터치에서 차단.
- upstream 결함 추가 수정: Rust `feature_shell.html`·`glossary_raw_shell.html`의 CSS/JS 토큰(20261027)과 특집 하단 버전 표기(V00.194.03)가 낡아 있었다. sync_versions/verify_release_metadata 대상에 Rust 셸과 레거시 비교 fixture를 추가. 홈 레일 요청 간 공유는 upstream에서 이미 해결돼 회귀 테스트만 추가.
- 검증: test:rust 348/348, test:rust:pages 3/3(workerd), cargo test, 이식 테스트 site-stability 8·seo-resilience·article-export·post-markdown, site-share-login·public-ssr·scout-topics, node --check, diff --check, audit:exposure, verify_release_metadata. 원본 코드로 되돌리면 결함 테스트 4개가 실패함을 확인.
- 배포: 소유자 승인으로 03a35735 push, 깨끗한 main 복제본에서 표준 배포 exit0(Pages 57531295). 라이브 VERSION 00.195.03, sitemap 기사 URL 554, 공개 기사 감사 554건/오류0, snapshot 20261101T103518Z-03a35735. 용어집 원문 업데이트 2026-10-08 표시, 특집 하단 V00.195.03·자산 토큰 일치 확인. 503 경로는 운영에서 일부러 재현하지 않았다(테스트로만 확인).
- 남은 일: rules/03 의 프로덕션 버그 KMS 케이스 스터디 기록(10-22 work 폴더의 제안서 기반)은 아직 하지 않았다.

## 2026-11-01 — M3 스타일시트 캐스케이드 단일화·디자인 토큰 통합·구버전 데드 CSS 정리 (Site 00.196.00, 배포 완료)

- 사용자 지시: 메테리얼 디자인(M3) 전환 과정에서 꼬인 BP미디어 코드를 최신화하고 합리적으로 정리(커밋·푸시·배포 위임 포함). 작업 위치는 맥북 에어 `/Users/jimmy/gilwell-media`(`main`, 기준 HEAD `808f7e56`).
- 스타일시트 로딩 순서 단일화(`style.css` → 페이지 전용 CSS → `chatbot.css` → `dark-mode.css` → `m3-site.css`): `public/index.html`, `glossary.html`, `memorabilia.html`, `404.html`(`style.css` 추가), `500.html`(`dark-mode.css` 추가), `functions/post/[id].js`, `functions/glossary-raw.js`, `server-rust/src/glossary_raw_shell.html`, `tests/fixtures/rust-article-page.js`, `tests/fixtures/rust-glossary-raw.js` 정렬.
- CSS 토큰 통합 및 데드 코드 제거(순 719줄 감축):
  - `public/css/style.css`: 5곳에 흩어져 있던 `:root` 디자인 토큰 블록을 최상단 단일 블록으로 통합, 현재 `admin.html`이 `admin-v3.css`만 단독 로드함에도 남아 있던 구버전 V1/V2 관리자 전용 데드 CSS(`body.admin-page`, `.admin-header*`, `.admin-sidebar*`, `.admin-tab*`, `.admin-shell` 등) 제거, 자기 덮어쓰기 중복 선언(`.section-header`, `.home-col-header`) 및 분산 `@media (pointer: coarse)` 통합(~630줄 감축).
  - `public/css/dark-mode.css`: 5개 최상위 `:root[data-theme="dark"]` 블록을 단일 블록으로 통합, 모순되던 구버전 헤더 주석 및 미사용 V1 관리자 다크모드 셀렉터 제거.
  - `public/css/m3-site.css`·`public/css/topics.css`: 중복 규칙(`.home-rail-card .mini-item`, `.topic-intro`, `.topic-guide`, `.topic-news-card` 등) 및 쪼개진 `@media (max-width: 900px / 600px / 599px / prefers-reduced-motion)` 블록을 데스크톱 우선 내림차순으로 병합.
- 검증·감사 스크립트 및 테스트 최신화:
  - `scripts/verify_release_metadata.sh`: `SITE_STYLE_FILES`·`M3_STYLE_FILES` 검사 범위를 22개 모든 공개 HTML/SSR 표면으로 확장.
  - `scripts/audit_css_usage.mjs`·`prune_dead_css.mjs`·`audit_orphans.sh`의 구 경로 및 임시저장(draft) 오탐 쿼리 수정.
  - `tests/rust-posts.test.mjs`: Node 26 `node:sqlite`의 `undefined` 바인딩 허용 동작 변경에 맞춰 D1 mock의 `run()`이 Cloudflare D1과 동일하게 `undefined` 바인딩을 명시 거부하도록 보강.
- 검증: `npm run test:rust` 348/348, `test:analytics` 28/28, `test:search-performance` 8/8, `test:card-news` 통과, `site-stability`·`seo-resilience`·`public-ssr`·`scout-topics`·`article-export`·`post-markdown` 13/13 통과, `audit_frontend_refs.mjs --strict` Critical 0건, `audit_public_exposure.mjs` OK, `release_preflight.sh` 통과.
- 배포: 커밋 `1496b401` `origin/main` push 완료, 표준 배포 `CI=1 ./scripts/deploy_production.sh` exit 0(Pages `513d24dc`). 라이브 VERSION `00.196.00`·ASSET_VERSION `20261101123955` 확인, 공개 기사 감사 554건/오류 0건, release snapshot `20261101T124759Z-1496b401` 저장 완료.
- 추가 파일·폴더·Admin CSS 정리(Admin `03.162.00`): `public/css/admin.css` 하단에 잘못 들어가 있던 Admin v3 도감 자동완성·일괄수정·행사 그룹 규칙을 `public/css/admin-v3.css`로 이관하고, `admin.css`(`kms.html` 전용 로드) 내 구버전 V1/V2 관리자 데드 CSS 4,112줄을 제거(7,692줄→3,430줄). 완료된 일회성 마이그레이션 스크립트 7종(`migrate_existing_images_to_r2.mjs`, `migrate_semantic_color_tokens.mjs`, `normalize_scale.mjs`, `split_css.mjs`, `prune_dead_css.mjs`, `dead-css-classes.txt`, `test-totp.mjs`)과 빈 루트 `img/` 폴더 및 임시 덤프 폴더(`.playwright-mcp`, `output`, `test-results`, `.freebuff`)를 정리하고 `Desktop/VS_Code/bpmedia-material3`도 동일하게 최신 동기화했다.


2026-11-02 작업 중: 관리자 카드뉴스에서 ISO 주차를 선택해 해당 월~일 KST 공개 기사로 수동 호를 준비하고 기존 호를 재사용하는 변경을 작성했다. 기존 최근 7일 수동 제작 및 자동 제작 중지 상태를 유지한다. 로컬 검증과 운영 배포는 각각 별도 상태로 확인한다.

## 2026-11-08 — 캘린더 폐지 릴리스 (배포 준비)

- 최신 사용자 결정: 문서·번역본 자료실 계획 취소, 캘린더 기능 제거만 수행. 승인 전 커밋·푸시·배포하지 않음.
- 기존 제보 문구 미배포 변경 보존. 캘린더 전용 페이지·JS·CSS·관리자 패널/모달·API 구현·Rust 모듈과 메뉴/사이트맵 연결 제거. 기존 주소는 데이터 접근 없이410(no-store/noindex).
- 기존 calendar_events35건·설정·통계·이력 보존. 운영 DB 쓰기 없음. 문서 샘플 서버8797 종료, 샘플은 ignored work에만 보관.
- KMS 운영 원본/revision6은 배포 전 상태를 유지. 승인 후 폐지 기준·API 종료를 KMS에 반영하고 snapshot을 동기화해야 함. 로컬 제안·검증은 work/calendar-removal.

- 사용자 최종 배포 승인: "반영해서 업데이트해줘". 이번 릴리스에는 캘린더 제거만 포함하며 기존 제보 문구 미배포 변경은 제외.
- KMS revision6→7 CAS 갱신, 이전 본문 settings_history 보관·operational_events 기록·전체 readback 일치. 일정35건 보존.
- 릴리스 버전 Site00.198.00 / Admin03.165.00. 독립 배포 사본에서 필수 검증·표준 배포 후 결과를 추가한다.
