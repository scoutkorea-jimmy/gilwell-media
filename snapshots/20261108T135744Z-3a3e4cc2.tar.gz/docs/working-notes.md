---
tags: [ai-guide, working-notes, site, admin]
aliases: [작업 효율성 노트, Working Notes]
scope: site-admin
---

# 작업 효율성 노트 (Site / Admin)

> [!info] 세션 인사이트 누적
> 실제 작업 중 반복적으로 발견한 함정·패턴을 모은 체크리스트. 새 기능 착수 전이나 회귀 디버깅 전에 한 번 훑으면 30분~1시간 절약됨. 새 인사이트는 발견 즉시 이 파일에 prepend로 추가.
>
> 이 노트는 매 턴마다 컨텍스트에 자동 로드되지는 않습니다. CLAUDE.md에서 포인터만 유지하고, AI는 회귀 디버깅·신규 기능 착수 시 직접 읽도록 합니다.

## 15 공개 사이트 CSS 캐스케이드 표준 순서 · Rust 셸 자산 동기화 · Node 26 SQLite 바인딩 (00.196.00)

- **표준 CSS 로딩 순서**: 모든 공개 HTML, SSR(`functions/post/[id].js`, `functions/glossary-raw.js`, `functions/feature/[category]/[slug].js`), Rust 셸(`server-rust/src/*_shell.html`), 비교 픽스처(`tests/fixtures/rust-*.js`)는 반드시 다음 순서를 따른다:
  `style.css` → 페이지 전용 CSS(`home-banner.css` / `topics.css` / `glossary.css` / `memorabilia.css`) → `chatbot.css` → `dark-mode.css` → `m3-site.css`.
  - `dark-mode.css`나 `topics.css`가 `m3-site.css` 뒤에 오면 M3 역할 토큰/컴포넌트 오버라이드가 깨지므로 주의.
  - `scripts/verify_release_metadata.sh`가 22개 모든 공개 HTML/SSR 표면의 `style.css` 및 `m3-site.css` 자산 토큰 일치를 강제 검사한다.
- **`sync_versions.sh` 후 반드시 `npm run build:rust` 실행**: `sync_versions.sh`가 `server-rust/src/feature_shell.html`과 `glossary_raw_shell.html`의 `?v=<ASSET_VERSION>` 및 버전 문자열을 갱신하므로, `sync_versions.sh` 실행 뒤에 `npm run build:rust`를 돌려야 Wasm 바이너리 내부 문자열도 최신 자산 버전과 일치해 `rust-ssr.test.mjs`가 통과한다.
- **Node 26 `node:sqlite` `undefined` 바인딩 주의**: Node 22에서는 `sqlite.prepare(sql).run(...args)`에 `undefined`가 포함되면 Cloudflare D1과 동일하게 예외가 발생했으나, Node 26(`v26.11+`)부터는 `node:sqlite`가 `undefined`를 `NULL`로 허용한다. D1 호환 테스트 mock(`tests/rust-posts.test.mjs`)에서는 `run()`에서 `args.some(v => v === undefined)`를 명시적으로 검사해야 D1 `D1_TYPE_ERROR` 계약 테스트가 깨지지 않는다.

## 14 `publish_at` 은 타임존 없는 **KST 벽시계**, `created_at` 은 **UTC** — 시간대 버그의 단일 원인

00.170.00 에서 **NEW 배지 사라짐**(Site)과 **접속 시간 히트맵 9시간 밀림**(Admin) 두 버그가 같은 원인이었다.

- **저장 규칙**: `normalizePublishAtInput`(`functions/_shared/post-input.js`)은 관리자가 입력한 KST 시각을 타임존 표기 없이 그대로 저장한다(예: `2026-06-03 21:05:00` = KST). 반면 `created_at` 은 UTC.
- **정답 규칙(서버 표준)**: `functions/_shared/post-public-date.js` `PUBLIC_DATE_EXPR` — `publish_at` 에 타임존(Z/`+`)이 **있으면 UTC→+9h**, **없으면 이미 KST(변형 없음)**. `created_at` 은 항상 +9h. SQL 에서 게시글 KST 시각이 필요하면 **반드시 이 식을 쓴다.**
- **함정**: 타임존 없는 문자열을 무조건 UTC 로 보고 `+9h` 더하는 코드가 곳곳에 있었다 →
  - 클라이언트 `GW._getKstDateParts`/`getPostDateMillis` 는 미표기 문자열에 `+00:00` 가정. `getPostPublicDate` 가 raw 를 그대로 넘겨 당일 글이 +9h 밀려 `isPostNew=false`. → `getPostPublicDate` 가 미표기 `publish_at` 에 `+09:00` 부여하도록 수정([js/main.js](../js/main.js)).
  - `functions/api/admin/analytics.js` 히트맵·태그 인사이트가 `datetime(COALESCE(publish_at,created_at),'+9 hours')` 로 publish_at 에도 +9h → 이중 변환. `POST_KST_EXPR`(PUBLIC_DATE_EXPR 동일 로직, alias `p.`) 신설 후 교체.
- **체크**: 게시글 시각을 KST 로 다룰 땐 (1) SQL → `PUBLIC_DATE_EXPR`/동형 식, (2) 클라 → `GW.getPostPublicDate`(이제 타임존 태깅됨)를 거칠 것. raw `publish_at` 에 `+9h`/`+00:00` 가정 금지.

## 13 배포·문서 작업 함정 (changelog 들여쓰기 · 순차 배포 · KMS 100KB)

기념품 조회수(00.169.00) 배포가 여러 번 막힌 케이스. 상세·재발 방지는 KMS 13.1.7.

- **changelog.json 들여쓰기**: `items[]` 요소 2-space(`  {`), 필드 4-space. Edit을 다른 들여쓰기로 쓰면 조용히 실패 → 엔트리 누락 → `verify_release_metadata.sh`가 전 배포 차단. 추가 후 `grep`/JSON 카운트로 실제 삽입 확인. `JSON.parse` 통과 ≠ 추가됨.
- **순차 배포**: D1 마이그레이션 → commit → push → deploy를 병렬 호출 금지. 앞 단계 차단 시 뒤 단계 전부 취소됨.
- **라이브 검증**: 배포 성공 판단은 출력이 아니라 `curl .../VERSION` + 엔드포인트 응답으로.
- **KMS D1 CLI 100KB 한계**: `settings.feature_definition` 전체 블롭 단일 SQL은 `SQLITE_TOOBIG`. 값 분할 `INSERT + UPDATE value||'...'`(history는 서브쿼리 스냅샷) 또는 관리자 PUT API. D1 먼저 갱신 → `sync_kms_snapshot.mjs` 재생성(md 직접 편집은 다음 sync에 덮임).
- **편집 전 실제 파일 읽기**: 탐색/추정 구조로 Edit `old_string`을 쓰면 "string not found"로 실패. 항상 실제 내용에서 복사.

## 1 Enum / 카탈로그 변경은 "원본 1곳 → 동기화 N곳"

backend 상수 한 줄을 바꾸면 항상 **검증·렌더·CSS** 사본까지 함께 확인해야 한다. grep으로 모든 사본을 찾기 전엔 커밋하지 말 것.

| 카탈로그 | 동기화 대상 |
|---|---|
| 지역연맹 (Africa/Arab/Asia-Pacific/European/Interamerican/WOSM/Unclassified) | `functions/api/settings/reference-sites.js` `ALLOWED_FEDERATIONS` + `canonicalFederation` / `js/admin-v3.js` `_getGeoRegionCatalog` + `_canonicalGeoRegion` + `_getGeoRegionTone` / `css/admin-v3.css` `.v3-geo-region-badge.is-XXX` (3개 셀렉터 + legend dot) |
| Editor 슬롯 (A·B·C 잠금 + D~Z 자유) | `functions/api/settings/editors.js` `REQUIRED_LETTERS` + `normalizeEditors` / `js/admin-v3.js` `EDITOR_REQUIRED_LETTERS` + `_normalizeEditorsResponse` + `_addEditorRow` + `_renderEditors` |
| Editor.A 기본값 (publish byline fallback) | `functions/post/[id].js` / `functions/api/posts/[id].js` / `functions/api/posts/index.js` / `functions/api/settings/author.js` |

확인 명령:
```bash
grep -rn "ALLOWED_FEDERATIONS\|REQUIRED_LETTERS\|Editor\.A" --include="*.js" --include="*.css" .
```

## 2 `functions/api/settings/*` PUT 권한 게이트 정렬

`onRequestGet` → `gateMenuAccess(..., '<slug>', 'view')` / `onRequestPut`·`Post`·`Delete` → `'write'`. `'view'`로 잘못 적힌 PUT은 보기 권한자가 저장 가능한 잠재 버그.

확인 명령 (PUT인데 `view`인 곳이 있으면 출력):
```bash
grep -A2 "onRequestPut\|onRequestPost\|onRequestDelete" functions/api/settings/*.js | grep -B1 "gateMenuAccess.*'view'"
```

실제 사례: `functions/api/settings/contributors.js` PUT이 `'view'`로 잘못돼 있어 03.109.01에서 `'write'`로 수정.

## 3 공개 페이지 ↔ admin 메뉴 라벨 정합성

공개 페이지 제목이 admin 메뉴/카드 제목과 다르면 사용자는 "기능 누락"으로 보고한다. **사용자가 어떤 admin 기능이 사라졌다고 할 때 첫 번째 의심은 라벨 불일치.**

| 공개 페이지 | 공개 라벨 | admin 라벨 (현재) |
|---|---|---|
| `/contributors` | 도움을 주신 분들 | 도움 주신 분들 ✅ (이전 `기고자` → 수정) |
| `/wosm-members` | 세계연맹 회원국 현황 | 세계연맹 회원국 ✅ |
| `/glossary` | 용어집 | 용어집 ✅ |

새 admin 패널 만들 때: 카드 제목·사이드바·`v3-settings-nav-btn` 3곳 모두 공개 라벨과 동일하게.

## 4 admin은 `css/style.css`를 로드하지 않음

`admin.html`은 `css/admin-v3.css`만 로드. 따라서 **공용 UI 컴포넌트(banner, toast, overlay 등)는 양쪽 CSS에 중복 정의** 필요. 변경 시 한 곳만 고치면 다른 쪽에서 깨진다.

- 신규 컴포넌트 추가 시 `grep -n "<클래스명>" css/style.css css/admin-v3.css`로 양쪽 존재 여부 먼저 확인
- admin에서 z-index는 모달(8000) 밑(`< 8000`)으로 두어 폼 입력 차단 방지

실제 사례: `.gw-update-banner`(새 빌드 알림)는 style.css(공개, z=10000) + admin-v3.css(admin, z=7000) 둘 다 정의됨.

## 5 모달 패턴 — `v3-overlay` + `v3-modal`

표준 구조:
```html
<div class="v3-overlay" id="my-modal" style="display:none;">
  <div class="v3-modal v3-modal-lg">
    <div class="v3-modal-head">제목 <button data-close="my-modal">×</button></div>
    <div class="v3-modal-body">…</div>
    <div class="v3-modal-foot">…</div>
  </div>
</div>
```

- 오픈: `el.style.display = 'flex'`
- 닫기: `el.style.display = 'none'`
- `[data-close="<id>"]` 버튼은 **글로벌 delegator**(`js/admin-account.js:934-948`)가 자동 처리 → 별도 바인딩 불필요
- **backdrop 클릭으로 닫기는 4개 모달만 자동 동작** (account-user, account-permission, account-temp-password, account-preset). 새 모달은 자체 backdrop listener 필요:
  ```js
  el.addEventListener('click', e => { if (e.target === el) close(); });
  ```

실제 사례: 03.109.00의 `#refsite-modal`은 자체 backdrop 핸들러 추가했음.

## 6 Prod D1 직접 write는 차단됨

Bash로 `wrangler d1 execute ... UPDATE/INSERT/DELETE`를 시도하면 auto-mode 분류기가 거부. 대안 (우선순위 순):
1. 관리자 UI에서 사용자가 직접 처리
2. 기존 `/api/admin/*` 엔드포인트를 통해 인증된 변경
3. 사용자에게 명시 허가 요청 후 한 번만 실행

`SELECT`는 자유 허용. P0 이슈 해결도 D1 직접 UPDATE 대신 관리자 → `사이트 오류/이슈 기록` 패널에서 처리.

## 7 배포 후 검증은 apex 도메인 사용

`www.bpmedia.net`은 라우팅 차이로 522 응답할 수 있음. `https://bpmedia.net`(apex)이 신뢰 가능.

```bash
curl -s 'https://bpmedia.net/api/version' | python3 -m json.tool
```

`scripts/post_deploy_check.sh`도 apex를 BASE_URL 기본값(`https://bpmedia.net`)으로 사용 중.

## 8 `homepage_issues` 자동 보고 severity 표준

| 코드 | severity | 사용자 영향 |
|---|---|---|
| `home_initial_fetch_failed` | high | 첫 로드 차단 |
| `home_client_runtime_error` | high | JS 깨짐 |
| `home_latest_refresh_failed` | **low** | 배경 새로고침만, 자연 복구 |
| `admin_client_runtime_error` | high | 운영자 작업 차단 |
| `admin_client_promise_rejection` | medium | 일부 비동기만 실패 |
| `admin_client_api_error` | medium | 운영자만 |

원칙: **사용자가 새로고침으로 복구 가능한 백그라운드 이벤트는 `low`**. 새 보고 코드 추가 시 이 표를 갱신.

## 9 버전·자산 동기화 4곳

`./scripts/sync_versions.sh` 실행 시 갱신되는 파일들:
1. `js/main.js` — `GW.APP_VERSION` / `GW.ADMIN_VERSION` / `GW.ASSET_VERSION`
2. 모든 공개 HTML + `admin.html` + `kms.html` — `?v=<ASSET_VERSION>` 토큰
3. `js/admin-v3.js` — `Version: <ADMIN_VERSION>` 주석
4. `functions/_shared/build-version.js` — `/api/version` 응답 (사용자 새 빌드 알림 배너)

새 버전 배포 시 사용자에게 알림이 자동 표시됨 (00.135.00+). 신규 운영 자산(HTML/JS)을 추가하면 sync_versions.sh의 perl 라인에도 등록 필요.

## 10 변경 배치 vs 분할 배포

각 배포 = preflight ~30s + wrangler deploy ~30s + post-deploy check ~30s ≈ 1.5분. 관련 변경은 **한 커밋으로 모아서 1회 deploy**. 사용자 검증이 필요한 큰 변경만 단계별 분할.

이번 세션(03.109.00 → 03.111.00, 5회 배포)은 사용자 incremental 요청 때문에 분할했지만, 단일 작업이라면 1회면 충분했을 변경량.

## 11 시간대 처리 (재확인)

- `homepage_issues.created_at / occurred_at / updated_at` **= UTC 저장값**
- 사용자가 KST 시각을 말하면 -9시간 변환 후 D1 쿼리
- changelog `released_at`은 **KST**로 기록 (`TZ='Asia/Seoul' date '+%Y-%m-%d %H:%M:%S KST'`)

## 12 P0 점검 시 transient 패턴 구분

`homepage_issues` `severity=high status=open` 이라도 `occurrence_count <= 2` + `reporter = system:auto-home` + `summary = Load failed` 단일 메시지면 **일시 네트워크 단절** 가능성이 높다 (CLAUDE.md §0 Step 1 단서). 5분 디듀프 윈도우 (00.135.00+)로 이 패턴 추가 억제.
