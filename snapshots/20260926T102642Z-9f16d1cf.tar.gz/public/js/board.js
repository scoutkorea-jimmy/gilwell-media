/**
 * Gilwell Media · Bulletin Board Component
 * Depends on GW namespace from js/main.js.
 *
 * Usage:
 *   const board = new GW.Board({ category: 'korea', gridId: 'board-grid' });
 *   board.init();
 */
(function () {
  'use strict';

  /**
   * @param {object} opts
   * @param {string} opts.category   - page category key
   * @param {string|null} [opts.apiCategory] - actual API category filter
   * @param {boolean} [opts.enableWrite] - whether to expose write UI
   * @param {object} [opts.extraParams] - extra query params for public list/tag calls
   * @param {string} [opts.gridId]   - id of the grid container element
   * @param {string} [opts.countId]  - id of the post-count element
   * @param {string} [opts.moreId]   - id of the "load more" button
   * @param {string} [opts.modalId]  - id of the modal overlay element
   */
  function Board(opts) {
    this.category = opts.category;
    this.apiCategory = Object.prototype.hasOwnProperty.call(opts, 'apiCategory') ? opts.apiCategory : opts.category;
    this.enableWrite = opts.enableWrite !== false;
    this.extraParams = Object.assign({}, opts.extraParams || {});
    if (this.apiCategory && this.category !== 'latest' && !Object.prototype.hasOwnProperty.call(this.extraParams, 'sort')) {
      this.extraParams.sort = 'manual';
    }
    // Sort/period toggle state. 'default' uses the existing manual/latest sort;
    // 'popular' uses /api/posts?sort=popular&period=… (window: 24h/7d/30d/all).
    // Enabled everywhere by default (incl. 최신소식/latest); callers can opt out.
    this.enableSortControls = opts.enableSortControls !== false;
    this._sortMode = 'default';
    this._periodKey = '7d';
    // Publish-date filter (latest 페이지 전용). 1·7·30 = 최근 N일.
    // latest 기본은 30일이고 '전체' 개념은 노출하지 않는다. 다른 카테고리
    // 보드는 이 토글을 표시하지 않으며 0(미적용) 으로 둔다.
    this._daysFilter = this.category === 'latest' ? 30 : 0;
    if (this.enableSortControls) this._readSortStateFromUrl();
    this.gridEl   = document.getElementById(opts.gridId   || 'board-grid');
    this.countEl  = document.getElementById(opts.countId  || 'board-count');
    this.bannerTotalEl = document.getElementById(opts.bannerTotalId || 'board-banner-total');
    this.paginationEl = document.getElementById(opts.paginationId || 'board-pagination');
    this.modalEl  = document.getElementById(opts.modalId  || 'post-modal');
    this.bannerInfo = { event_name: '', event_date: '' };

    this.page          = 1;
    this.pageSize      = 16;
    this.totalPages    = 1;
    this.total         = 0;
    this.loading       = false;
    this._searchQuery  = '';
    this._selectedTag  = null;
    this._loginTurnstileWidgetId = null;
    this._loginTurnstileToken = '';
    this._galleryImages = [];
  }

  // 4줄(row) 단위 페이지네이션. 뷰포트별 grid-template-columns와 맞춘다.
  //   ≥901px : 4 cols → 16 / 페이지
  //   481~900: 2 cols → 8  / 페이지
  //   ≤480px : 1 col  → 4  / 페이지
  Board.prototype._getPageSize = function () {
    var w = window.innerWidth;
    if (w <= 480) return 4;
    if (w <= 900) return 8;
    return 16;
  };

  // ── Initialise ────────────────────────────────────────────
  Board.prototype.init = function () {
    var self = this;
    this.pageSize = this._getPageSize();
    this._lastFetchAt = 0;
    GW.setMastheadDate();
    GW.markActiveNav();
    this._setupModal();
    if (this.enableWrite) this._setupWriteFeature();
    this._setupSearch();
    if (this.enableSortControls) {
      this._setupSortControls();
      this._applySortStateToParams();
    }
    this._loadBoardLayout();
    this._loadBoardBannerInfo();
    this._load();
    this._loadTagBar();
    window.addEventListener('resize', function () {
      var nextPageSize = self._getPageSize();
      if (nextPageSize === self.pageSize) return;
      self.pageSize = nextPageSize;
      self._resetAndLoad();
    });
    // Auto-refresh on tab return: catches posts published from admin (or another
    // tab) without forcing the reader to hit reload. Only triggers when the
    // user is on page 1 — a reader paged deeper into history shouldn't be
    // yanked back to the top. Throttled by AUTO_REFRESH_MIN_SECONDS so it does
    // not stack up if multiple focus events fire in quick succession.
    document.addEventListener('visibilitychange', function () {
      if (document.visibilityState === 'visible') self._maybeAutoRefresh();
    });
    window.addEventListener('focus', function () { self._maybeAutoRefresh(); });
  };

  var AUTO_REFRESH_MIN_SECONDS = 20;
  Board.prototype._maybeAutoRefresh = function () {
    if (this.loading) return;
    if (this.page > 1) return;
    var now = Date.now();
    if (now - (this._lastFetchAt || 0) < AUTO_REFRESH_MIN_SECONDS * 1000) return;
    this._load({ silent: true });
  };

  Board.prototype._loadBoardLayout = function () {
    var self = this;
    fetch('/api/settings/board-layout', { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        var gap = parseInt(data && data.gap_px, 10);
        if (!Number.isFinite(gap)) gap = 6;
        gap = Math.min(40, Math.max(5, gap));
        if (self.gridEl) {
          self.gridEl.style.gap = gap + 'px';
          self.gridEl.style.marginTop = gap + 'px';
        }
      })
      .catch(function (err) { console.warn('[board] grid layout fetch failed:', err && err.message || err); });
  };

  Board.prototype._loadBoardBannerInfo = function () {
    var self = this;
    fetch('/api/settings/board-banner', { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        var items = data && data.items ? data.items : {};
        var item = items[self.category] || {};
        self.bannerInfo = {
          event_name: String(item.event_name || '').trim(),
          event_date: /^\d{4}-\d{2}-\d{2}$/.test(String(item.event_date || '').trim()) ? String(item.event_date).trim() : '',
        };
        self._updateCount();
      })
      .catch(function (err) { console.warn('[board] banner info fetch failed:', err && err.message || err); });
  };

  // ── Tag filter bar ────────────────────────────────────────
  Board.prototype._loadTagBar = function () {
    var self  = this;
    var barEl = document.getElementById('tag-filter-bar');
    if (!barEl) return;

    var url = '/api/posts/tags';
    var params = [];
    if (this.apiCategory) params.push('category=' + encodeURIComponent(this.apiCategory));
    Object.keys(this.extraParams).forEach(function (key) {
      var value = self.extraParams[key];
      if (value === null || value === undefined || value === '') return;
      params.push(encodeURIComponent(key) + '=' + encodeURIComponent(String(value)));
    });
    if (params.length) url += '?' + params.join('&');
    fetch(url)
      .then(function (r) { return r.json(); })
      .then(function (data) {
        var tags = data.tags || [];
        if (!tags.length) return;

        var html = '<div class="tag-filter-bar-inner"><span class="board-control-label board-tag-label">주제</span><button class="tag-filter-btn active" data-tag="">전체</button>';
        tags.forEach(function (t) {
          html += '<button class="tag-filter-btn" data-tag="' + GW.escapeHtml(t) + '">' + GW.escapeHtml(t) + '</button>';
        });
        html += '</div>';
        barEl.innerHTML = html;

        barEl.querySelectorAll('.tag-filter-btn').forEach(function (btn) {
          btn.addEventListener('click', function () {
            barEl.querySelectorAll('.tag-filter-btn').forEach(function (b) { b.classList.remove('active'); });
            btn.classList.add('active');
            self._selectedTag = btn.dataset.tag || null;
            self._resetAndLoad();
          });
        });
      })
      .catch(function (err) { console.warn('[board] tag bar fetch failed:', err && err.message || err); });
  };

  Board.prototype._resetAndLoad = function () {
    this.page    = 1;
    this.total   = 0;
    this.totalPages = 1;
    this.loading = false;
    this.gridEl.innerHTML = '';
    if (this.paginationEl) this.paginationEl.innerHTML = '';
    this._load();
  };

  // ── Load posts from API ───────────────────────────────────
  // opts.silent=true skips the loading-state grid blank-out so an auto-refresh
  // on tab return doesn't visually flash the existing list away.
  Board.prototype._load = function (opts) {
    if (this.loading) return;
    var self = this;
    var silent = !!(opts && opts.silent);
    this.loading = true;
    if (!silent) this._showLoading();
    this.pageSize = this._getPageSize();

    var searchParam = this._searchQuery ? '&q=' + encodeURIComponent(this._searchQuery) : '';
    var tagParam    = this._selectedTag  ? '&tag=' + encodeURIComponent(this._selectedTag)  : '';
    var endpoint = '/api/posts?page=' + this.page + '&limit=' + this.pageSize + searchParam + tagParam;
    if (this.apiCategory) endpoint += '&category=' + encodeURIComponent(this.apiCategory);
    Object.keys(this.extraParams).forEach(function (key) {
      var value = self.extraParams[key];
      if (value === null || value === undefined || value === '') return;
      endpoint += '&' + encodeURIComponent(key) + '=' + encodeURIComponent(String(value));
    });
    // Cache-bust every list fetch. The /api/posts response already sets
    // Cache-Control: no-store, but some browsers / service workers still serve
    // stale copies after admin publishes a new article in another tab. Adding a
    // unique _t query guarantees the request bypasses every layer of caching.
    endpoint += '&_t=' + Date.now();
    GW.apiFetch(endpoint, { cache: 'no-store' })
      .then(function (data) {
        self.total   = data.total;
        self.pageSize = data.pageSize || self.pageSize || 16;
        self.totalPages = Math.max(1, Math.ceil(self.total / self.pageSize));
        self._renderPosts(data.posts);
        self._updateCount();
        self._renderPagination();
        self._lastFetchAt = Date.now();
      })
      .catch(function (err) {
        console.error('[board] load failed:', err);
        if (!silent) { try { self._showError(); } catch (_) {} }
      })
      .finally(function () {
        self.loading = false;
      });
  };

  // ── Render cards ──────────────────────────────────────────
  Board.prototype._renderPosts = function (posts) {
    var self = this;
    this.gridEl.innerHTML = '';

    if (posts.length === 0) {
      this._showEmpty();
      return;
    }

    posts.forEach(function (post, i) {
      var card = self._buildCard(post, i);
      self.gridEl.appendChild(card);
    });
  };

  // 4줄 단위 번호 페이지네이션 (이전/1/2/3/…/다음)
  Board.prototype._renderPagination = function () {
    var self = this;
    if (!this.paginationEl) return;
    if (this.totalPages <= 1) {
      this.paginationEl.innerHTML = '';
      return;
    }

    var currentPage = this.page;
    var totalPages  = this.totalPages;
    var start = Math.max(1, currentPage - 2);
    var end   = Math.min(totalPages, start + 4);
    start = Math.max(1, end - 4);
    var html = '';

    if (currentPage > 1) {
      html += '<button type="button" class="board-page-btn board-page-nav" data-page="' + (currentPage - 1) + '" aria-label="이전 페이지">이전</button>';
    }
    if (start > 1) {
      html += '<button type="button" class="board-page-btn" data-page="1">1</button>';
      if (start > 2) html += '<span class="board-page-ellipsis" aria-hidden="true">…</span>';
    }
    for (var page = start; page <= end; page++) {
      html += '<button type="button" class="board-page-btn' + (page === currentPage ? ' active' : '') + '"' +
              ' data-page="' + page + '"' + (page === currentPage ? ' aria-current="page"' : '') + '>' + page + '</button>';
    }
    if (end < totalPages) {
      if (end < totalPages - 1) html += '<span class="board-page-ellipsis" aria-hidden="true">…</span>';
      html += '<button type="button" class="board-page-btn" data-page="' + totalPages + '">' + totalPages + '</button>';
    }
    if (currentPage < totalPages) {
      html += '<button type="button" class="board-page-btn board-page-nav" data-page="' + (currentPage + 1) + '" aria-label="다음 페이지">다음</button>';
    }
    this.paginationEl.innerHTML = html;
    this.paginationEl.querySelectorAll('[data-page]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var nextPage = parseInt(btn.getAttribute('data-page') || '1', 10);
        if (!Number.isFinite(nextPage) || nextPage < 1 || nextPage > self.totalPages || nextPage === self.page) return;
        self.page = nextPage;
        window.scrollTo({ top: 0, behavior: 'smooth' });
        self._load();
      });
    });
  };

  Board.prototype._buildCard = function (post, idx) {
    var self    = this;
    var cat     = GW.CATEGORIES[post.category] || GW.CATEGORIES.korea;
    var card    = document.createElement('article');
    card.className = 'post-card' + (post.image_url ? ' has-thumb' : ' no-thumb');
    card.style.animationDelay = (0.04 + idx * 0.04) + 's';
    card.style.setProperty('--card-accent', cat.color || '#111111');

    var thumb = '';
    if (post.image_url) {
      // Markup only — the onerror fallback is attached below via addEventListener
      // instead of an inline handler so that CSP can eventually drop 'unsafe-inline'.
      var thumbFrameStyle = post.image_is_placeholder ? '' : GW.thumbFrameStyle(post);
      thumb = '<img class="post-card-thumb' + (post.image_is_placeholder ? ' is-placeholder' : '') + '" src="' + GW.escapeHtml(post.image_url)
            + '"' + (thumbFrameStyle ? ' style="' + thumbFrameStyle + '"' : '')
            + ' alt="' + GW.escapeHtml(post.title || '') + '" loading="lazy">';
    }

    var isNew = GW.isPostNew(post);
    var shareHtml = '<div class="post-card-share-row"><button class="post-share-btn post-card-share-btn" type="button" data-share-url="/post/' + post.id + '" data-share-title="' + GW.escapeHtml(post.title) + '">공유하기</button></div>';
    var kickerHtml = (isNew ? '<span class="post-kicker post-kicker-new">NEW</span>' : '') +
      (post.tag ? post.tag.split(',').map(function(t){ t = t.trim(); return t ? '<span class="post-kicker ' + cat.tagClass + '-kicker">' + GW.escapeHtml(t) + '</span>' : ''; }).join('') : '');
    // 게시판 카테고리 태그(채움)와 글머리 태그(아웃라인) 동시 표시
    var labelsHtml = '<span class="category-tag ' + cat.tagClass + '">' + cat.label + '</span>' + kickerHtml;
    var subtitleHtml = post.subtitle
      ? '<p class="post-card-subtitle">' + GW.escapeHtml(post.subtitle) + '</p>'
      : '';

    card.innerHTML =
      thumb +
      '<div class="post-card-body">' +
        '<div class="post-card-head">' +
          '<div class="post-card-labels">' + labelsHtml + '</div>' +
          // 제목을 실제 <a> 로 — 키보드 포커스/Enter 이동 + 크롤러용 진짜 링크. 카드 전체 클릭은 점진 향상.
          '<h3><a class="post-card-title-link" href="/post/' + post.id + '">' + GW.escapeHtml(post.title) + '</a></h3>' +
        '</div>' +
        subtitleHtml +
        '<p class="post-card-excerpt">' + GW.escapeHtml(GW.truncate(post.content || '', 140)) + '</p>' +
        '<div class="post-card-footer">' +
          shareHtml +
          '<div class="post-card-engagement">공감 ' + GW.formatNumber(post.likes || 0) + '</div>' +
          '<div class="post-card-meta">' +
            GW.renderPostDateLabel(post) +
            (post.author ? ' &nbsp;·&nbsp; <span class="post-author">' + GW.escapeHtml(post.author) + '</span>' : '') +
            ' &nbsp;<a class="post-permalink" href="/post/' + post.id + '" title="개별 페이지로 이동">기사 보기</a>' +
          '</div>' +
        '</div>' +
      '</div>';

    var thumbEl = card.querySelector('.post-card-thumb');
    if (thumbEl) {
      thumbEl.addEventListener('error', function () {
        card.classList.remove('has-thumb');
        card.classList.add('no-thumb');
        thumbEl.remove();
      }, { once: true });
    }

    card.addEventListener('click', function (e) {
      if (e.target.classList.contains('post-permalink')) return;
      if (e.target.classList.contains('post-card-share-btn')) return;
      if (e.target.closest('.post-card-title-link')) return; // 제목 링크가 직접 이동 처리
      window.location.href = '/post/' + post.id;
    });
    var shareBtn = card.querySelector('.post-card-share-btn');
    if (shareBtn) {
      shareBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        var url = new URL('/post/' + post.id, window.location.origin).toString();
        GW.sharePostLink({ url: url, title: post.title, text: post.title })
          .catch(function (err) {
            GW.showToast((err && err.message) || '링크 공유에 실패했습니다', 'error');
          });
      });
    }
    return card;
  };

  // ── Post detail modal ─────────────────────────────────────
  Board.prototype._setupModal = function () {
    var self = this;
    if (!this.modalEl) return;

    this.modalEl.addEventListener('click', function (e) {
      if (e.target === self.modalEl) self._closePost();
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') self._closePost();
    });
  };

  Board.prototype._openPost = function (id) {
    var self = this;
    if (!this.modalEl) return;

    var inner = this.modalEl.querySelector('.modal');
    if (inner) {
      inner.innerHTML =
        '<button class="modal-close" onclick="document.getElementById(\'post-modal\').classList.remove(\'open\')">×</button>' +
        '<div class="loading-state"><div class="loading-dots"><span></span><span></span><span></span></div></div>';
    }
    this.modalEl.classList.add('open');
    document.body.style.overflow = 'hidden';

    GW.apiFetch('/api/posts/' + id)
      .then(function (data) { self._renderModal(data.post); })
      .catch(function () {
        if (inner) {
          inner.innerHTML =
            '<button class="modal-close" onclick="document.getElementById(\'post-modal\').classList.remove(\'open\')">×</button>' +
            '<div class="error-state">게시글을 불러오지 못했습니다.</div>';
        }
      });
  };

  Board.prototype._renderModal = function (post) {
    var self  = this;
    var cat   = GW.CATEGORIES[post.category] || GW.CATEGORIES.korea;
    var inner = this.modalEl.querySelector('.modal');
    if (!inner) return;

    var imgHtml = '';
    if (post.image_url) {
      imgHtml = '<div class="modal-image-frame"><img class="modal-img" src="' + GW.escapeHtml(post.image_url) + '" alt="' + GW.escapeHtml(post.title || '') + '"></div>' +
        GW.buildImageCaption(post.image_caption);
    }
    var youtubeHtml = GW.buildYouTubeEmbed(post.youtube_url, post.title);

    var modalTagHtml = (GW.isPostNew(post) ? '<span class="post-kicker post-kicker-new">NEW</span>' : '') +
      (post.tag ? post.tag.split(',').map(function(t){ t = t.trim(); return t ? '<span class="post-kicker ' + cat.tagClass + '-kicker">' + GW.escapeHtml(t) + '</span>' : ''; }).join('') : '');

    var subtitleHtml = post.subtitle
      ? '<p class="modal-subtitle">' + GW.escapeHtml(post.subtitle) + '</p>'
      : '';
    var renderedContent = GW.renderTextWithMedia(post.content);
    var relatedHtml = buildRelatedPostsHtml(post.related_posts);
    var galleryHtml = GW.renderContentGallery(parseGalleryImages(post.gallery_images), { className: 'modal-content-gallery' });
    var locationHtml = buildPostLocationHtml(post);

    inner.innerHTML =
      '<button class="modal-close" id="modal-close-btn" aria-label="닫기">×</button>' +
      '<div class="modal-header">' +
        '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:12px;">' +
          '<span class="category-tag ' + cat.tagClass + '">' + cat.label + '</span>' +
          modalTagHtml +
        '</div>' +
        '<h2>' + GW.escapeHtml(post.title) + '</h2>' +
        subtitleHtml +
        '<div class="modal-date">' + GW.renderPostDateLabel(post) + '</div>' +
      '</div>' +
      imgHtml +
      youtubeHtml +
      '<div class="modal-body">' + renderedContent.html + '</div>' +
      locationHtml +
      galleryHtml +
      relatedHtml +
      '<div class="post-byline">' +
        (post.author ? '<span class="post-byline-author">작성자 · ' + GW.escapeHtml(post.author) + '</span>' : '') +
        '<span class="post-byline-report">오류제보 <a href="mailto:info@bpmedia.net">info@bpmedia.net</a></span>' +
      '</div>';

    inner.querySelector('#modal-close-btn').addEventListener('click', function () {
      self._closePost();
    });
    GW.initContentGalleries(inner);
    _initLocationMap(inner);
  };

  Board.prototype._closePost = function () {
    if (!this.modalEl) return;
    this.modalEl.classList.remove('open');
    document.body.style.overflow = '';
  };

  function buildRelatedPostsHtml(items) {
    if (!Array.isArray(items) || !items.length) return '';
    return '<section class="modal-related-posts">' +
      '<h3 class="post-related-heading">유관기사 읽어보기</h3>' +
      '<ul class="post-related-list">' +
        items.map(function (item) {
          var category = GW.CATEGORIES[item.category] || GW.CATEGORIES.korea;
          return '<li><a href="/post/' + item.id + '">[' + GW.escapeHtml(category.label) + '] ' + GW.escapeHtml(item.title || '') + '</a></li>';
        }).join('') +
      '</ul>' +
    '</section>';
  }

  function buildPostLocationHtml(post) {
    var locationAddress = post && post.location_address ? String(post.location_address).trim() : '';
    if (!locationAddress) return '';
    var locationName = post && post.location_name ? String(post.location_name).trim() : '';
    var mapTitle = locationName || locationAddress;
    // Map is loaded async via _initLocationMap() after the modal renders
    return '<details class="post-location-section" open>' +
      '<summary>위치 정보 보기</summary>' +
      '<div class="post-location-body">' +
        (locationName ? '<div class="post-location-name">' + GW.escapeHtml(locationName) + '</div>' : '') +
        '<div class="post-location-address">' + GW.escapeHtml(locationAddress) + '</div>' +
        '<div class="post-location-map-frame" data-location-addr="' + GW.escapeHtml(locationAddress) + '" data-location-title="' + GW.escapeHtml(mapTitle) + '">' +
          '<div class="post-location-map-loading" style="display:flex;align-items:center;justify-content:center;height:280px;color:#888;font-size:13px;">지도를 불러오는 중…</div>' +
        '</div>' +
      '</div>' +
    '</details>';
  }

  function _initLocationMap(container) {
    var mapFrames = container.querySelectorAll('.post-location-map-frame[data-location-addr]');
    mapFrames.forEach(function (frame) {
      var addr  = frame.getAttribute('data-location-addr') || '';
      var title = frame.getAttribute('data-location-title') || addr;
      if (!addr) return;
      fetch('https://nominatim.openstreetmap.org/search?q=' + encodeURIComponent(addr) + '&format=json&limit=1', {
        headers: { 'Accept-Language': 'ko,en', 'User-Agent': 'GilwellMedia/1.0' }
      })
        .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(function (results) {
          if (!results || !results.length) {
            frame.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:280px;color:#888;font-size:12px;">지도에서 위치를 찾을 수 없습니다</div>';
            return;
          }
          var loc = results[0];
          var lat = parseFloat(loc.lat), lon = parseFloat(loc.lon);
          var d = 0.01;
          var bbox = (lon - d) + ',' + (lat - d) + ',' + (lon + d) + ',' + (lat + d);
          var src = 'https://www.openstreetmap.org/export/embed.html?bbox=' + bbox + '&layer=mapnik&marker=' + lat + ',' + lon;
          frame.innerHTML = '<iframe class="post-location-map" src="' + src + '" title="' + GW.escapeHtml(title) + ' 지도" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>';
        })
        .catch(function () {
          frame.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:280px;color:#888;font-size:12px;">지도를 불러오지 못했습니다</div>';
        });
    });
  }

  function parseGalleryImages(raw) {
    if (!raw) return [];
    if (Array.isArray(raw)) return raw;
    try {
      var parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch (_) {
      return [];
    }
  }

  // ── State displays ────────────────────────────────────────
  Board.prototype._showLoading = function () {
    this.gridEl.innerHTML =
      '<div class="loading-state">' +
        '<div class="loading-dots"><span></span><span></span><span></span></div>' +
      '</div>';
  };

  Board.prototype._showEmpty = function () {
    this.gridEl.innerHTML =
      '<div class="empty-state" style="grid-column:1/-1;">' +
        '<span class="empty-icon">◌</span>' +
        '<p>아직 게시된 글이 없습니다.<br>관리자가 첫 번째 글을 올릴 예정입니다.</p>' +
      '</div>';
  };

  Board.prototype._showError = function () {
    if (this.page === 1) {
      this.gridEl.innerHTML =
        '<div class="error-state" style="grid-column:1/-1;">게시글을 불러오지 못했습니다. 잠시 후 다시 시도해주세요.</div>';
    }
  };

  Board.prototype._updateCount = function () {
    if (this.countEl) this.countEl.textContent = '총 ' + this.total + '개';
    if (!this.bannerTotalEl) return;

    var eventName = this.bannerInfo && this.bannerInfo.event_name;
    var eventDate = this.bannerInfo && this.bannerInfo.event_date;
    var dday = getDdayLabel(eventDate);
    if (eventName && dday) {
      this.bannerTotalEl.classList.add('has-event');
      this.bannerTotalEl.innerHTML =
        '<div class="board-banner-total-label">' + GW.escapeHtml(eventName) + '</div>' +
        '<div class="board-banner-total-value">' + GW.escapeHtml(dday) + '</div>';
      return;
    }

    this.bannerTotalEl.classList.remove('has-event');
    this.bannerTotalEl.textContent = this.total + '개';
  };

  function getDdayLabel(dateStr) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(dateStr || ''))) return '';
    var parts = dateStr.split('-').map(function (part) { return parseInt(part, 10); });
    var targetUtc = Date.UTC(parts[0], parts[1] - 1, parts[2]);
    if (!Number.isFinite(targetUtc)) return '';
    var now = new Date();
    var kstText = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Seoul',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(now);
    var currentParts = kstText.split('-').map(function (part) { return parseInt(part, 10); });
    var todayUtc = Date.UTC(currentParts[0], currentParts[1] - 1, currentParts[2]);
    var diff = Math.round((targetUtc - todayUtc) / 86400000);
    if (diff === 0) return 'D-Day';
    return diff > 0 ? 'D-' + diff : 'D+' + Math.abs(diff);
  }

  // ── Board search ──────────────────────────────────────────
  Board.prototype._setupSearch = function () {
    var self = this;
    var container = document.querySelector('.board-container');
    if (!container) return;

    var wrap = document.createElement('div');
    wrap.className = 'board-search-wrap';
    wrap.innerHTML =
      '<div class="board-search-inner">' +
        '<input type="text" id="board-search-input" class="board-search-input" placeholder="이 게시판에서 검색…" autocomplete="off" />' +
        '<button class="board-search-clear" id="board-search-clear" style="display:none;">✕</button>' +
      '</div>';
    container.insertBefore(wrap, container.firstChild);

    var input  = document.getElementById('board-search-input');
    var clear  = document.getElementById('board-search-clear');
    var timer  = null;

    input.addEventListener('input', function () {
      var q = input.value.trim();
      clear.style.display = q ? 'block' : 'none';
      clearTimeout(timer);
      timer = setTimeout(function () { self._search(q); }, 350);
    });

    clear.addEventListener('click', function () {
      input.value = '';
      clear.style.display = 'none';
      self._search('');
    });
  };

  Board.prototype._search = function (q) {
    this._searchQuery = q;
    this.page    = 1;
    this.total   = 0;
    this.totalPages = 1;
    this.loading = false;
    this.gridEl.innerHTML = '';
    this._load();
  };

  // ── Sort & period controls ────────────────────────────────
  // UI: 페이지 의미에 맞는 "최신 기사/추천 기사" ↔ "많이 본 기사" + 기간 controls.
  // Popular ranks by (window views) + (window likes × 3); "전체" falls back to
  // cumulative views + likes × 3. State is mirrored to the URL as
  // ?sort=popular&period=7d so links are shareable.
  var VALID_PERIODS = ['24h', '7d', '30d', 'all'];
  var PERIOD_LABELS = { '24h': '24시간', '7d': '7일', '30d': '30일', 'all': '전체' };

  var VALID_DAYS_FILTER = [1, 7, 30];
  var DAYS_FILTER_LABELS = { 1: '하루', 7: '일주일', 30: '30일' };

  Board.prototype._readSortStateFromUrl = function () {
    try {
      var qs = new URLSearchParams(window.location.search);
      var sort = String(qs.get('sort') || '').toLowerCase();
      var period = String(qs.get('period') || '').toLowerCase();
      if (sort === 'popular') this._sortMode = 'popular';
      if (VALID_PERIODS.indexOf(period) !== -1) this._periodKey = period;
      // Only latest page exposes this control, so only read it there.
      if (this.category === 'latest') {
        var daysRaw = parseInt(qs.get('days') || '0', 10);
        if (VALID_DAYS_FILTER.indexOf(daysRaw) !== -1) this._daysFilter = daysRaw;
      }
    } catch (_) { /* SSR / non-browser safe */ }
  };

  Board.prototype._setupSortControls = function () {
    var self = this;
    var tagBar = document.getElementById('tag-filter-bar');
    var container = document.querySelector('.board-container');
    if (!container) return;

    // latest 페이지는 인기 윈도우 칩 대신 publish-date 필터 토글을 노출한다.
    // 다른 카테고리 보드는 그 반대 (인기 윈도우 칩만, publish 필터는 없음).
    var isLatest = this.category === 'latest';
    var defaultSortLabel = isLatest ? '최신 기사' : '추천 기사';

    var bar = document.createElement('div');
    bar.className = 'board-sort-bar';
    bar.innerHTML =
      '<div class="board-control-group board-sort-group">' +
        '<span class="board-control-label">정렬</span>' +
        '<div class="board-sort-toggle" role="tablist" aria-label="정렬 방식">' +
          '<button type="button" class="board-sort-btn" data-sort="default" role="tab" aria-selected="false">' + defaultSortLabel + '</button>' +
          '<button type="button" class="board-sort-btn" data-sort="popular" role="tab" aria-selected="false">많이 본 기사</button>' +
        '</div>' +
      '</div>' +
      (isLatest
        ? '<div class="board-control-group board-days-group">' +
            '<span class="board-control-label">게시 기간</span>' +
            '<div class="board-days-bar" role="group" aria-label="게시 기간 선택">' +
              VALID_DAYS_FILTER.map(function (n) {
                return '<button type="button" class="board-days-btn" data-days="' + n + '">' + DAYS_FILTER_LABELS[n] + '</button>';
              }).join('') +
            '</div>' +
          '</div>'
        : '<div class="board-control-group board-period-group" hidden>' +
            '<span class="board-control-label">집계 기간</span>' +
            '<div class="board-period-bar" role="group" aria-label="인기 집계 기간 선택">' +
              VALID_PERIODS.map(function (key) {
                return '<button type="button" class="board-period-btn" data-period="' + key + '">' + PERIOD_LABELS[key] + '</button>';
              }).join('') +
            '</div>' +
          '</div>');

    if (tagBar && tagBar.parentNode) {
      tagBar.parentNode.insertBefore(bar, tagBar);
    } else {
      container.insertBefore(bar, container.firstChild);
    }
    this._sortBarEl = bar;

    bar.querySelectorAll('.board-sort-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var next = btn.getAttribute('data-sort') === 'popular' ? 'popular' : 'default';
        if (next === self._sortMode) return;
        self._sortMode = next;
        self._applySortStateToParams();
        self._renderSortControls();
        self._resetAndLoad();
      });
    });
    bar.querySelectorAll('.board-period-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var next = btn.getAttribute('data-period') || '7d';
        if (VALID_PERIODS.indexOf(next) === -1) next = '7d';
        if (next === self._periodKey) return;
        self._periodKey = next;
        self._applySortStateToParams();
        self._renderSortControls();
        self._resetAndLoad();
      });
    });
    bar.querySelectorAll('.board-days-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var next = parseInt(btn.getAttribute('data-days') || '0', 10);
        if (VALID_DAYS_FILTER.indexOf(next) === -1) next = 0;
        if (next === self._daysFilter) return;
        self._daysFilter = next;
        self._applySortStateToParams();
        self._renderSortControls();
        self._resetAndLoad();
      });
    });

    this._renderSortControls();
  };

  Board.prototype._renderSortControls = function () {
    if (!this._sortBarEl) return;
    var mode = this._sortMode;
    var period = this._periodKey;
    this._sortBarEl.querySelectorAll('.board-sort-btn').forEach(function (btn) {
      var active = btn.getAttribute('data-sort') === (mode === 'popular' ? 'popular' : 'default');
      btn.classList.toggle('active', active);
      btn.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    var periodGroup = this._sortBarEl.querySelector('.board-period-group');
    if (periodGroup) {
      if (mode === 'popular') periodGroup.removeAttribute('hidden');
      else periodGroup.setAttribute('hidden', '');
    }
    this._sortBarEl.querySelectorAll('.board-period-btn').forEach(function (btn) {
      btn.classList.toggle('active', btn.getAttribute('data-period') === period);
    });
    var days = String(this._daysFilter || 0);
    this._sortBarEl.querySelectorAll('.board-days-btn').forEach(function (btn) {
      btn.classList.toggle('active', String(btn.getAttribute('data-days') || '0') === days);
    });
  };

  Board.prototype._applySortStateToParams = function () {
    var isLatest = this.category === 'latest';
    // latest 페이지는 기간 칩이 없으므로 popular 모드일 때 period=all 고정 (누적 점수).
    var effectivePeriod = isLatest ? 'all' : this._periodKey;
    if (this._sortMode === 'popular') {
      this.extraParams.sort = 'popular';
      this.extraParams.period = effectivePeriod;
    } else {
      this.extraParams.sort = (this.apiCategory && !isLatest) ? 'manual' : 'latest';
      delete this.extraParams.period;
    }
    // Latest 전용 publish-date 필터. 항상 1/7/30 중 하나가 강제된다 ('전체' 없음).
    if (isLatest) {
      this.extraParams.days = this._daysFilter || 30;
    } else {
      delete this.extraParams.days;
    }
    // Mirror to URL so the view is shareable and survives reloads.
    try {
      var url = new URL(window.location.href);
      if (this._sortMode === 'popular') {
        url.searchParams.set('sort', 'popular');
        if (isLatest) {
          url.searchParams.delete('period');
        } else {
          url.searchParams.set('period', this._periodKey);
        }
      } else {
        url.searchParams.delete('sort');
        url.searchParams.delete('period');
      }
      if (isLatest) {
        // default(30) 은 URL 깔끔하게 유지하기 위해 명시 안 함.
        if (this._daysFilter && this._daysFilter !== 30) {
          url.searchParams.set('days', String(this._daysFilter));
        } else {
          url.searchParams.delete('days');
        }
      }
      window.history.replaceState(null, '', url.toString());
    } catch (_) { /* ignore history failures (non-browser env) */ }
  };

  // ── Export ────────────────────────────────────────────────
  GW.Board = Board;

})();
