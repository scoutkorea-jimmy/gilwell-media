// AUTO-MANAGED — values are rewritten by scripts/sync_versions.sh on every
// release. Do not edit by hand; bump VERSION / ADMIN_VERSION / ASSET_VERSION
// files instead and run ./scripts/sync_versions.sh.
export const SITE_VERSION = '00.191.01';
export const ADMIN_VERSION = '03.153.02';
export const ASSET_VERSION = '20260926102118';
